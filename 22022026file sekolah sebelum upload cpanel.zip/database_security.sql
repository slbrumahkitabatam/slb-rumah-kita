-- Security Tables for SLB Rumah Kita Batam
-- Jalankan file ini untuk membuat tabel-tabel keamanan

-- Tabel untuk mencatat percobaan login (rate limiting)
CREATE TABLE IF NOT EXISTS `login_attempts` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `username` VARCHAR(100) NOT NULL,
    `ip_address` VARCHAR(45) NOT NULL,
    `attempt_time` DATETIME NOT NULL,
    `is_locked` TINYINT(1) DEFAULT 0,
    `lockout_until` DATETIME NULL,
    PRIMARY KEY (`id`),
    INDEX `idx_ip_time` (`ip_address`, `attempt_time`),
    INDEX `idx_username` (`username`),
    INDEX `idx_lockout` (`is_locked`, `lockout_until`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabel untuk mencatat log keamanan
CREATE TABLE IF NOT EXISTS `security_logs` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `event_type` VARCHAR(50) NOT NULL,
    `description` TEXT NOT NULL,
    `username` VARCHAR(100) NULL,
    `ip_address` VARCHAR(45) NOT NULL,
    `event_time` DATETIME NOT NULL,
    `user_agent` VARCHAR(255) NULL,
    PRIMARY KEY (`id`),
    INDEX `idx_event_type` (`event_type`),
    INDEX `idx_time` (`event_time`),
    INDEX `idx_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabel untuk CSRF tokens (opsional, bisa menggunakan session)
CREATE TABLE IF NOT EXISTS `csrf_tokens` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `token` VARCHAR(64) NOT NULL,
    `session_id` VARCHAR(128) NOT NULL,
    `created_at` DATETIME NOT NULL,
    `expires_at` DATETIME NOT NULL,
    `used` TINYINT(1) DEFAULT 0,
    PRIMARY KEY (`id`),
    INDEX `idx_token` (`token`),
    INDEX `idx_session` (`session_id`),
    INDEX `idx_expires` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Clean up function untuk maintenance otomatis
DELIMITER $$

CREATE PROCEDURE IF NOT EXISTS `clean_security_tables`()
BEGIN
    -- Hapus login attempts lebih dari 24 jam
    DELETE FROM login_attempts WHERE attempt_time < DATE_SUB(NOW(), INTERVAL 24 HOUR);
    
    -- Hapus security logs lebih dari 90 hari
    DELETE FROM security_logs WHERE event_time < DATE_SUB(NOW(), INTERVAL 90 DAY);
    
    -- Hapus CSRF tokens yang sudah expired
    DELETE FROM csrf_tokens WHERE expires_at < NOW() OR used = 1;
END$$

DELIMITER ;

-- Event scheduler untuk auto-cleanup (jika di-enable di server)
-- Uncomment baris di bawah ini jika ingin mengaktifkan auto-cleanup
-- SET GLOBAL event_scheduler = ON;
-- CREATE EVENT IF NOT EXISTS clean_security_event
-- ON SCHEDULE EVERY 1 DAY
-- DO CALL clean_security_tables();