# Panduan Deployment ke Hosting/cPanel

## 📋 Prasyarat
Sebelum melakukan deployment, pastikan Anda memiliki:
- Akun hosting/cPanel aktif
- Akses ke cPanel atau File Manager
- Akses ke MySQL Database Wizard atau phpMyAdmin
- FTP client (FileZilla, WinSCP, dll.) atau cPanel File Manager

---

## 🚀 Langkah-Langkah Deployment

### 1. Persiapan File di Localhost

#### 1.1. Export Database
```sql
# Buka phpMyAdmin di localhost
# Pilih database: rumahkitabtmweb_ftth
# Klik tab "Export"
# Pilih format: SQL
# Klik "Go" untuk download

# Atau gunakan perintah di terminal:
mysqldump -u root -p rumahkitabtmweb_ftth > database_export.sql
```

#### 1.2. Kompres Semua File
```bash
# Di root project, zip semua file (kecuali .git dan file lain yang tidak perlu)
# Include semua folder: admin, config, gambar, includes, uploads, dll.
# File yang perlu diupload:
  - Semua file .php
  - Folder admin/
  - Folder config/
  - Folder gambar/
  - Folder includes/
  - Folder uploads/
  - File .htaccess (jika ada)
```

### 2. Upload ke Hosting

#### 2.1. Upload File via cPanel File Manager
1. Login ke cPanel
2. Buka "File Manager"
3. Masuk ke folder `public_html` (atau subfolder jika ingin di subdomain)
4. Upload file .zip yang sudah dibuat
5. Extract file .zip tersebut
6. Pastikan struktur folder sama dengan localhost

#### 2.2. Upload via FTP (FileZilla)
```
Host: nama-domain.com (atau IP server)
Username: username FTP cPanel
Password: password FTP cPanel
Port: 21
```

1. Connect ke server
2. Navigate ke `public_html`
3. Upload semua file dan folder

### 3. Setup Database di Hosting

#### 3.1. Buat Database Baru
1. Login ke cPanel
2. Buka "MySQL Database Wizard"
3. Buat database baru:
   - Database Name: `slb_rumah_kita` (atau sesuai keinginan)
   - Catat nama database lengkap (biasanya: `usercp_nama_db`)
4. Buat user database:
   - Username: `slb_user` (atau sesuai keinginan)
   - Password: Buat password yang kuat
   - Catat username lengkap (biasanya: `usercp_username`)
5. Grant all privileges pada user untuk database tersebut

#### 3.2. Import Database
1. Buka phpMyAdmin di cPanel
2. Pilih database yang baru dibuat
3. Klik tab "Import"
4. Pilih file `.sql` yang sudah di-export dari localhost
5. Klik "Go" untuk import

**Atau gunakan SQL:**
Jika ingin menggunakan file `database_complete.sql`, jalankan perintah CREATE DATABASE di phpMyAdmin:
```sql
CREATE DATABASE IF NOT EXISTS slb_rumah_kita CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE slb_rumah_kita;
-- Kemudian import file database_complete.sql
```

### 4. Konfigurasi Database di Hosting

#### 4.1. Edit File `config/database.php`
Buka file `config/database.php` di File Manager, lalu edit bagian konfigurasi hosting:

```php
} else {
    // KONFIGURASI HOSTING/cPanel
    // Edit bagian ini saat deploy ke hosting
    define('DB_HOST', 'localhost'); // Biasanya localhost di cPanel
    define('DB_USER', 'usercp_username_dbuser');     // Ganti dengan username database cPanel
    define('DB_PASS', 'password_database_anda');     // Ganti dengan password database cPanel
    define('DB_NAME', 'usercp_slb_rumah_kita');      // Ganti dengan nama database cPanel
}
```

**Contoh:**
Jika di cPanel:
- Database name: `user1234_slb_rumah_kita`
- Database user: `user1234_slbuser`
- Password: `P@ssw0rd!123`

Maka konfigurasinya:
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'user1234_slbuser');
define('DB_PASS', 'P@ssw0rd!123');
define('DB_NAME', 'user1234_slb_rumah_kita');
```

#### 4.2. Simpan Perubahan
Klik "Save Changes" di File Manager

### 5. Setup Permission Folder

Pastikan folder yang memerlukan write permission memiliki permission yang benar:

```bash
# Di cPanel File Manager, set permission folder berikut:
uploads/       → 755 atau 777 (jika perlu write)
gambar/        → 755 (read-only untuk gambar statis)
```

### 6. Testing Aplikasi

#### 6.1. Akses Website
Buka browser dan akses: `https://nama-domain.com`

#### 6.2. Cek Error Log
Jika ada error, cek:
1. File error log di cPanel: `public_html/error_log`
2. Pastikan konfigurasi database sudah benar
3. Cek PHP version (minimal PHP 7.4 atau 8.x)

#### 6.3. Test Login Admin
1. Akses: `https://nama-domain.com/admin`
2. Login dengan akun yang sudah ada di database:
   - Username: `admin`
   - Password: `password` (sesuai yang ada di database)

---

## 🔧 Troubleshooting

### Masalah: Database Connection Failed
**Solusi:**
1. Cek kembali konfigurasi di `config/database.php`
2. Pastikan database name, username, dan password benar
3. Pastikan user database sudah di-grant privileges
4. Coba test connection via phpMyAdmin

### Masalah: Gambar Tidak Tampil
**Solusi:**
1. Cek apakah folder `gambar/` dan `uploads/` sudah ada
2. Cek permission folder (755 atau 777)
3. Pastikan file gambar sudah diupload
4. Cek BASE_URL di `config/database.php` sudah benar

### Masalah: 500 Internal Server Error
**Solusi:**
1. Cek file `.htaccess` (jika ada)
2. Cek PHP version di cPanel (Select PHP Version)
3. Pastikan extension PHP yang diperlukan aktif:
   - PDO
   - PDO_MySQL
   - GD (untuk gambar)
   - MBString
   - JSON

### Masalah: Session Tidak Berfungsi
**Solusi:**
1. Pastikan folder `tmp` atau `session` ada dan writable
2. Cek `session.save_path` di php.ini
3. Pastikan tidak ada output sebelum session_start()

### Masalah: File Upload Gagal
**Solusi:**
1. Cek permission folder `uploads/` (777 untuk testing, 755 untuk production)
2. Cek upload_max_filesize di php.ini (minimal 10M)
3. Cek post_max_size di php.ini (minimal 10M)

---

## 📝 Checklist Deployment

- [ ] Export database dari localhost
- [ ] Upload semua file ke hosting
- [ ] Buat database baru di cPanel
- [ ] Import database ke hosting
- [ ] Edit konfigurasi database di `config/database.php`
- [ ] Set permission folder yang diperlukan
- [ ] Test akses website
- [ ] Test login admin
- [ ] Test CRUD (Create, Read, Update, Delete)
- [ ] Test upload gambar
- [ ] Cek semua tampilan dan fungsi
- [ ] Backup database di hosting

---

## 🔒 Security Best Practices

### 1. Protect Folder Config
Buat file `.htaccess` di folder `config/`:
```apache
Order Deny,Allow
Deny from all
```

### 2. Protect File .git
Jika menggunakan Git, buat file `.htaccess`:
```apache
<FilesMatch "\.git">
    Order allow,deny
    Deny from all
</FilesMatch>
```

### 3. Change Default Password
- Ganti password admin default
- Ganti password database hosting

### 4. Enable HTTPS
- Install SSL certificate (biasanya gratis dari Let's Encrypt di cPanel)
- Force HTTPS via `.htaccess`:
```apache
RewriteEngine On
RewriteCond %{HTTPS} off
RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
```

### 5. Regular Backup
- Schedule backup database di cPanel
- Backup file secara berkala

---

## 📞 Bantuan Tambahan

Jika mengalami masalah:
1. Cek error log: `public_html/error_log`
2. Cek access log di cPanel
3. Hubungi support hosting Anda
4. Pastikan semua requirements terpenuhi

---

## ✅ Verifikasi Setelah Deployment

### Cek dengan skrip test
Buat file `test.php` di root website:
```php
<?php
// Test Database Connection
require 'config/database.php';

echo "<h1>Test Deployment</h1>";
echo "<h2>1. Database Connection</h2>";
try {
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM users");
    $result = $stmt->fetch();
    echo "✅ Database Connected: Found " . $result['total'] . " users<br>";
} catch (PDOException $e) {
    echo "❌ Database Error: " . $e->getMessage() . "<br>";
}

echo "<h2>2. Base URL</h2>";
echo "BASE_URL: " . BASE_URL . "<br>";
echo "BASE_PATH: " . BASE_PATH . "<br>";

echo "<h2>3. Folder Check</h2>";
$folders = ['uploads', 'gambar', 'config'];
foreach ($folders as $folder) {
    if (is_dir(BASE_PATH . '/' . $folder)) {
        echo "✅ Folder " . $folder . " exists<br>";
    } else {
        echo "❌ Folder " . $folder . " NOT found<br>";
    }
}

echo "<h2>4. PHP Version</h2>";
echo "PHP Version: " . phpversion() . "<br>";

echo "<h2>5. Database Tables</h2>";
try {
    $stmt = $pdo->query("SHOW TABLES");
    $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
    foreach ($tables as $table) {
        echo "✅ Table: " . $table . "<br>";
    }
} catch (PDOException $e) {
    echo "❌ Error: " . $e->getMessage() . "<br>";
}

// Hapus file ini setelah testing
echo "<br><strong>Jangan lupa hapus file test.php ini setelah testing selesai!</strong>";
?>
```

Akses: `https://nama-domain.com/test.php`

---

**Selamat! Website Anda sudah siap berjalan di hosting! 🎉**

---

*Dokumentasi ini dibuat untuk membantu deployment aplikasi SLB Rumah Kita ke hosting/cPanel.*