<?php
require_once 'includes/header.php';

echo "<h1>Test Logika Gambar Berita</h1>";
echo "<h2>1. Test Default Image Variable:</h2>";
$defaultNewsImage = 'gambar/beitadefault.png';
echo "defaultNewsImage = " . $defaultNewsImage . "<br>";
echo "File exists: " . (file_exists($defaultNewsImage) ? 'YES' : 'NO') . "<br>";

echo "<h2>2. Test Database Berita:</h2>";
require_once 'config/database.php';
$berita = fetchAll("SELECT id, judul, gambar FROM berita LIMIT 3");

echo "<table border='1' cellpadding='10'>";
echo "<tr><th>ID</th><th>Judul</th><th>Gambar Value</th><th>IF Condition</th><th>Image Source</th></tr>";

foreach ($berita as $item) {
    $gambarValue = $item['gambar'];
    $ifCondition = $gambarValue ? 'TRUE (ada gambar)' : 'FALSE (pakai default)';
    $imageSource = $gambarValue ? "uploads/berita/" . htmlspecialchars($gambarValue) : $defaultNewsImage;
    
    echo "<tr>";
    echo "<td>" . $item['id'] . "</td>";
    echo "<td>" . htmlspecialchars($item['judul']) . "</td>";
    echo "<td>" . ($gambarValue ? htmlspecialchars($gambarValue) : 'NULL/KOSONG') . "</td>";
    echo "<td><strong>$ifCondition</strong></td>";
    echo "<td>$imageSource</td>";
    echo "</tr>";
}
echo "</table>";

echo "<h2>3. Test Actual Image Display:</h2>";
echo "<h3>Default Image:</h3>";
echo "<img src='$defaultNewsImage' alt='Default' style='max-width: 200px; border: 2px solid green;'><br>";

foreach ($berita as $item) {
    echo "<h3>Berita ID " . $item['id'] . " - " . htmlspecialchars($item['judul']) . "</h3>";
    if ($item['gambar']) {
        $src = "uploads/berita/" . htmlspecialchars($item['gambar']);
        echo "<p>Using uploaded image: $src</p>";
        echo "<img src='$src' alt='" . htmlspecialchars($item['judul']) . "' style='max-width: 200px; border: 2px solid blue;'><br>";
    } else {
        echo "<p>Using DEFAULT image: $defaultNewsImage</p>";
        echo "<img src='$defaultNewsImage' alt='" . htmlspecialchars($item['judul']) . "' style='max-width: 200px; border: 2px solid red;'><br>";
    }
    echo "<hr>";
}

echo "<h2>4. Recommendation:</h2>";
$hasEmpty = false;
foreach ($berita as $item) {
    if (!$item['gambar']) {
        $hasEmpty = true;
        break;
    }
}

if ($hasEmpty) {
    echo "<p style='color: green;'>✓ Ada berita tanpa gambar. Default image SEHARUSNYA tampil di halaman berita.php</p>";
    echo "<p>Jika tidak tampil, berarti ada masalah dengan path di berita.php</p>";
} else {
    echo "<p style='color: orange;'>⚠ SEMUA berita sudah memiliki gambar. Default image tidak akan pernah tampil.</p>";
    echo "<p>Untuk melihat default image, Anda perlu:</p>";
    echo "<ul>";
    echo "<li>Membuat berita baru tanpa upload gambar, atau</li>";
    echo "<li>Mengupdate salah satu berita untuk menghapus gambarnya</li>";
    echo "</ul>";
    echo "<p><strong>Test: Buat berita baru di admin dan jangan upload gambar, lalu lihat di halaman berita.php</strong></p>";
}
?>