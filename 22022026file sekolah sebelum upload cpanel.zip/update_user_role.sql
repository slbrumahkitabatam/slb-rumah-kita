-- Tambah kolom role ke tabel users
-- Jalankan ini di phpMyAdmin untuk menambahkan kolom role

-- Tambah kolom role
ALTER TABLE users ADD COLUMN role VARCHAR(20) DEFAULT 'guru' AFTER nama;

-- Update existing users (user pertama jadi admin, lainnya guru)
UPDATE users SET role = 'admin' WHERE id = 1;
UPDATE users SET role = 'guru' WHERE id > 1 OR id IS NULL;

-- Tambah index untuk role (opsional, untuk performa)
ALTER TABLE users ADD INDEX idx_role (role);