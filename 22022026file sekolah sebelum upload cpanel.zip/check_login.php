<?php
session_start();

echo "<h1>🔍 Cek Status Login</h1>";

// Cek session
echo "<div class='alert alert-info'>";
echo "<h3>Status Session:</h3>";
echo "<ul>";

if (isset($_SESSION['user_id'])) {
    echo "<li class='text-success'>✅ user_id: " . $_SESSION['user_id'] . "</li>";
} else {
    echo "<li class='text-danger'>❌ user_id: TIDAK ADA</li>";
}

if (isset($_SESSION['username'])) {
    echo "<li class='text-success'>✅ username: " . $_SESSION['username'] . "</li>";
} else {
    echo "<li class='text-danger'>❌ username: TIDAK ADA</li>";
}

if (isset($_SESSION['nama'])) {
    echo "<li class='text-success'>✅ nama: " . $_SESSION['nama'] . "</li>";
} else {
    echo "<li class='text-danger'>❌ nama: TIDAK ADA</li>";
}

if (isset($_SESSION['role'])) {
    echo "<li class='text-success'>✅ role: " . $_SESSION['role'] . "</li>";
} else {
    echo "<li class='text-danger'>❌ role: TIDAK ADA</li>";
}

echo "</ul>";
echo "</div>";

// Cek apakah bisa akses admin pages
echo "<div class='card mt-3'>";
echo "<div class='card-header'><h5>Test Akses Halaman Admin</h5></div>";
echo "<div class='card-body'>";

// Test 1: Cek apakah login
if (!isset($_SESSION['user_id'])) {
    echo "<div class='alert alert-danger'>❌ BELUM LOGIN</div>";
    echo "<p>Silakan login dulu: <a href='admin/login.php'>Login</a></p>";
    echo "<p>Username: admin | Password: admin123</p>";
} else {
    echo "<div class='alert alert-success'>✅ SUDAH LOGIN</div>";
    
    // Test 2: Cek apakah admin
    if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
        echo "<div class='alert alert-warning'>⚠️ BUKAN ADMIN (Role: " . ($_SESSION['role'] ?? 'null') . ")</div>";
        echo "<p>Role Anda adalah '" . ($_SESSION['role'] ?? 'null') . "', tapi halaman Manajemen User membutuhkan role 'admin'</p>";
    } else {
        echo "<div class='alert alert-success'>✅ ADMIN</div>";
        echo "<p>Anda memiliki akses penuh</p>";
    }
}

echo "</div>";
echo "</div>";

// Link ke halaman
echo "<div class='card mt-3'>";
echo "<div class='card-header'><h5>Link Navigasi</h5></div>";
echo "<div class='card-body'>";
echo "<div class='list-group'>";
echo "<a href='admin/login.php' class='list-group-item list-group-item-action'>Login Page</a>";
echo "<a href='admin/index.php' class='list-group-item list-group-item-action'>Dashboard</a>";
echo "<a href='admin/user.php' class='list-group-item list-group-item-action' style='background: #e3f2fd;'>Manajemen User (admin/user.php)</a>";
echo "</div>";
echo "</div>";
echo "</div>";

// Debug info
echo "<div class='card mt-3'>";
echo "<div class='card-header'><h5>Debug Info</h5></div>";
echo "<div class='card-body'>";
echo "<pre>";
print_r($_SESSION);
echo "</pre>";
echo "</div>";
echo "</div>";

?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cek Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container mt-5">
        <!-- Content above is PHP output -->
    </div>
</body>
</html>