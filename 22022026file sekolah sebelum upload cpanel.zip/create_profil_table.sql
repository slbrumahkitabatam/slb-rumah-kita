-- Buat tabel terpisah untuk profil sekolah
CREATE TABLE IF NOT EXISTS profil_sekolah (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tentang TEXT NOT NULL,
    visi_misi TEXT NOT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Insert data dari tabel halaman jika ada
INSERT INTO profil_sekolah (tentang, visi_misi)
SELECT 
    (SELECT isi FROM halaman WHERE slug = 'tentang' LIMIT 1),
    (SELECT isi FROM halaman WHERE slug = 'visi-misi' LIMIT 1)
WHERE NOT EXISTS (SELECT 1 FROM profil_sekolah);