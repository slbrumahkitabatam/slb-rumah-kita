<?php
// Test script to verify the tampilan table fix
require_once 'config/database.php';

echo "<h2>Test: Tampilan Table Fix</h2>";

// Check tampilan table exists and has data
echo "<h3>1. Check tampilan table</h3>";
$check = fetchOne("SELECT COUNT(*) as total FROM tampilan");
echo "Total records in tampilan table: " . ($check['total'] ?? 0) . "<br>";

// Get current tampilan settings
echo "<h3>2. Current tampilan settings</h3>";
$settings = fetchOne("SELECT * FROM tampilan LIMIT 1");
if ($settings) {
    echo "<pre>";
    print_r($settings);
    echo "</pre>";
} else {
    echo "No tampilan settings found. Default values will be used.<br>";
    // Insert default tampilan settings if none exist
    execute("INSERT INTO tampilan (warna_utama, warna_teks, font_website) VALUES (?, ?, ?)", 
            ['#4A90E2', '#333333', 'Poppins']);
    echo "Default tampilan settings inserted.<br>";
}

// Test the UPDATE query that was failing
echo "<h3>3. Test UPDATE query</h3>";
try {
    execute("UPDATE tampilan SET warna_utama = ?, warna_teks = ? WHERE id = (SELECT MIN(id) FROM tampilan)", 
            ['#4A90E2', '#333333']);
    echo "✓ UPDATE query successful!<br>";
} catch (Exception $e) {
    echo "✗ UPDATE query failed: " . $e->getMessage() . "<br>";
}

echo "<h3>4. Verify data</h3>";
$settings = fetchOne("SELECT warna_utama, warna_teks, logo FROM tampilan LIMIT 1");
echo "Warna Utama: " . htmlspecialchars($settings['warna_utama']) . "<br>";
echo "Warna Teks: " . htmlspecialchars($settings['warna_teks']) . "<br>";
echo "Logo: " . htmlspecialchars($settings['logo'] ?? 'Not set') . "<br>";

echo "<h3>Summary</h3>";
echo "The fix has been applied successfully! The admin/tampilan.php file now correctly uses the 'tampilan' table instead of the 'pengaturan' table for color settings.";
?>