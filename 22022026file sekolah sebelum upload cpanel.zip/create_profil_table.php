<?php
// File untuk membuat tabel profil_sekolah secara otomatis

require_once 'config/database.php';

// Buat tabel
$sql = "CREATE TABLE IF NOT EXISTS profil_sekolah (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tentang TEXT NOT NULL,
    visi_misi TEXT NOT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)";

try {
    execute($sql);
    echo "✅ Tabel 'profil_sekolah' berhasil dibuat!<br><br>";
    
    // Cek apakah ada data
    $existing = fetchOne("SELECT id FROM profil_sekolah LIMIT 1");
    
    if (!$existing) {
        // Coba ambil data dari tabel halaman
        $tentang_lama = fetchOne("SELECT isi FROM halaman WHERE slug = 'tentang' LIMIT 1");
        $visi_lama = fetchOne("SELECT isi FROM halaman WHERE slug = 'visi-misi' LIMIT 1");
        
        if ($tentang_lama || $visi_lama) {
            // Insert data dari tabel halaman
            $tentang = $tentang_lama ? $tentang_lama['isi'] : '<p>Tentang sekolah...</p>';
            $visi = $visi_lama ? $visi_lama['isi'] : '<h3>Visi</h3><p>Visi sekolah...</p><h3>Misi</h3><ol><li>Misi 1</li></ol>';
            
            execute(
                "INSERT INTO profil_sekolah (tentang, visi_misi) VALUES (?, ?)",
                [$tentang, $visi]
            );
            echo "✅ Data profil berhasil diambil dari tabel halaman!<br>";
        } else {
            // Insert data default
            $default_tentang = '<p>SLB Rumah Kita Batam adalah sekolah luar biasa yang berdedikasi untuk memberikan pendidikan terbaik bagi siswa berkebutuhan khusus. Dengan fasilitas yang lengkap dan guru-guru profesional, kami berkomitmen untuk membantu setiap siswa mencapai potensi maksimal mereka.</p>';
            $default_visi = '<h3>Visi</h3><p>Menjadi sekolah luar biasa unggulan yang memberikan layanan pendidikan berkualitas bagi siswa berkebutuhan khusus.</p><h3>Misi</h3><ol><li>Memberikan pendidikan yang sesuai dengan kebutuhan setiap siswa</li><li>Mengembangkan potensi dan bakat siswa secara optimal</li><li>Membangun kerjasama dengan orang tua dan masyarakat</li><li>Meningkatkan kualitas guru dan staf pendidikan</li><li>Menyediakan fasilitas pendidikan yang memadai</li></ol>';
            
            execute(
                "INSERT INTO profil_sekolah (tentang, visi_misi) VALUES (?, ?)",
                [$default_tentang, $default_visi]
            );
            echo "✅ Data default berhasil dimasukkan!<br>";
        }
    } else {
        echo "ℹ️ Data profil sudah ada, tidak perlu di-insert ulang.<br>";
    }
    
    echo "<br><strong>✅ Selesai!</strong> Tabel profil_sekolah sudah siap digunakan.<br>";
    echo "<a href='admin/profil.php' class='btn btn-primary mt-3'>Buka Admin Profil</a>";
    
} catch (PDOException $e) {
    echo "❌ Error: " . $e->getMessage();
}
?>