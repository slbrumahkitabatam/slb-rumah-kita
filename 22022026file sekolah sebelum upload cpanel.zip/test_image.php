<?php
// Test file untuk memverifikasi gambar default
$defaultImage = 'gambar/beitadefault.png';

echo "<h1>Test Gambar Default</h1>";
echo "<p>Path gambar: " . $defaultImage . "</p>";
echo "<p>File exists: " . (file_exists($defaultImage) ? 'YES' : 'NO') . "</p>";

// Tampilkan gambar
echo "<h2>Test Tampil Gambar:</h2>";
echo "<img src='$defaultImage' alt='Test Image' style='max-width: 500px; border: 2px solid red;'>";

// Test path relatif
echo "<h2>Test Path Relatif:</h2>";
echo "<p>Current working directory: " . getcwd() . "</p>";
echo "<p>Full path: " . realpath($defaultImage) . "</p>";

// Cek database berita
echo "<h2>Database Check:</h2>";
require_once 'config/database.php';
$berita = fetchAll("SELECT id, judul, gambar FROM berita LIMIT 3");
echo "<table border='1' cellpadding='10'>";
echo "<tr><th>ID</th><th>Judul</th><th>Gambar (Database)</th><th>Conditional Test</th></tr>";
foreach ($berita as $item) {
    $hasGambar = !empty($item['gambar']) ? 'ADA GAMBAR' : 'TIDAK ADA (pakai default)';
    echo "<tr>";
    echo "<td>" . $item['id'] . "</td>";
    echo "<td>" . htmlspecialchars($item['judul']) . "</td>";
    echo "<td>" . ($item['gambar'] ? htmlspecialchars($item['gambar']) : 'NULL/KOSONG') . "</td>";
    echo "<td><strong>$hasGambar</strong></td>";
    echo "</tr>";
}
echo "</table>";
?>