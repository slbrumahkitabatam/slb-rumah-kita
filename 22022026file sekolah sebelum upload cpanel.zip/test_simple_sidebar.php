<?php
session_start();
$_SESSION['user_id'] = 1;
$_SESSION['username'] = 'admin';
$_SESSION['nama'] = 'Administrator';
$_SESSION['role'] = 'admin';
$active_menu = 'user';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test Simple Sidebar</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            display: flex;
            font-family: Arial, sans-serif;
        }
        #sidebar {
            width: 250px;
            background: #4A90E2;
            color: white;
            padding: 20px;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
        }
        #content {
            margin-left: 250px;
            padding: 20px;
            flex-grow: 1;
        }
        a {
            display: block;
            color: white;
            text-decoration: none;
            padding: 10px;
            margin: 5px 0;
            border: 1px solid white;
            cursor: pointer;
        }
        a:hover {
            background: rgba(255,255,255,0.2);
        }
        .nav-label {
            font-weight: bold;
            margin-top: 20px;
            margin-bottom: 10px;
            padding: 5px;
            background: rgba(0,0,0,0.2);
        }
    </style>
</head>
<body>
    <div id="sidebar">
        <h2>Admin Panel</h2>
        
        <div class="nav-label">Menu Utama</div>
        <a href="admin/index.php">Dashboard</a>
        <a href="admin/berita.php">Berita</a>
        <a href="admin/galeri.php">Galeri</a>
        <a href="admin/profil.php">Profil Sekolah</a>
        
        <div class="nav-label">Manajemen</div>
        <a href="admin/guru.php">Guru & Staf</a>
        <a href="admin/halaman.php">Halaman & Menu</a>
        <a href="admin/tampilan.php">Tampilan Website</a>
        <a href="admin/kontak.php">Kontak</a>
        
        <div class="nav-label" style="background: yellow; color: black;">MANAJEMEN USER</div>
        <a href="admin/user.php" style="background: yellow; color: black; font-weight: bold;">
            👆 KLIK INI - MANAJEMEN USER
        </a>
        
        <div class="nav-label">Pengaturan</div>
        <a href="admin/pengaturan.php">Pengaturan</a>
        <a href="../index.php" target="_blank">Lihat Website</a>
        
        <div class="nav-label">Lainnya</div>
        <a href="admin/logout.php">Logout</a>
    </div>
    
    <div id="content">
        <h1>Test Sidebar Sederhana</h1>
        
        <div style="background: yellow; padding: 20px; border: 3px solid red; margin: 20px 0;">
            <h2>⚠️ INSTRUKSI PENTING:</h2>
            <p>1. Lihat sidebar di KIRI (kotak biru)</p>
            <p>2. Cari tulisan "MANAJEMEN USER" dengan background KUNING</p>
            <p>3. KLIK link yang bertuliskan "👆 KLIK INI - MANAJEMEN USER"</p>
            <p>4. Jika tidak bisa diklik, screenshot dan beritahu saya</p>
        </div>
        
        <div style="background: #e3f2fd; padding: 20px; border: 2px solid #2196F3;">
            <h3>Link Langsung:</h3>
            <a href="admin/user.php" style="display: inline-block; background: #4CAF50; color: white; padding: 15px 30px; text-decoration: none; border: none; font-size: 18px;">
                Buka admin/user.php
            </a>
        </div>
        
        <script>
        // Test click detection
        document.querySelectorAll('a').forEach(function(link) {
            link.addEventListener('click', function(e) {
                console.log('Link clicked:', this.href);
                alert('Anda mengklik: ' + this.href);
            });
        });
        </script>
    </div>
</body>
</html>