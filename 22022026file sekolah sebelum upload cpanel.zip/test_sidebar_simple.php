<?php
// Simple test to check if sidebar user section exists
session_start();
$_SESSION['user_id'] = 1;
$_SESSION['username'] = 'admin';
$_SESSION['nama'] = 'Administrator';
$_SESSION['role'] = 'admin';
$_SESSION['active_menu'] = 'user';

// Include sidebar
$active_menu = 'user';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test Sidebar Simple</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: #f5f7fa;
            margin-left: 280px;
            padding: 30px;
        }
    </style>
</head>
<body>
    <h1>Test Sidebar - Manajemen User Section</h1>
    
    <?php include 'admin/includes/sidebar.php'; ?>
    
    <div class="container mt-5">
        <div class="alert alert-info">
            <h3>Diagnosa:</h3>
            <p>1. Cek sidebar di kiri - apakah ada menu "Manajemen User"?</p>
            <p>2. Jika ada, klik untuk test</p>
            <p>3. Jika tidak ada, ada masalah dengan rendering sidebar</p>
        </div>
        
        <div class="card mt-3">
            <div class="card-header">
                <h5>Informasi Debug:</h5>
            </div>
            <div class="card-body">
                <p><strong>Active Menu:</strong> <?php echo $active_menu; ?></p>
                <p><strong>Session:</strong> <?php print_r($_SESSION); ?></p>
                <p><strong>Sidebar File:</strong> admin/includes/sidebar.php</p>
            </div>
        </div>
        
        <div class="card mt-3">
            <div class="card-header">
                <h5>Link Langsung ke User Management:</h5>
            </div>
            <div class="card-body">
                <a href="admin/user.php" class="btn btn-primary btn-lg">
                    <i class="fas fa-users-cog"></i> Buka admin/user.php
                </a>
            </div>
        </div>
    </div>
</body>
</html>