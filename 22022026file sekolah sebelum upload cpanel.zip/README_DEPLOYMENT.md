# 📦 Sistem Deployment Fleksibel - SLB Rumah Kita

## 🎯 Fitur Utama

Sistem ini dirancang agar aplikasi dapat berjalan dengan baik di **localhost** maupun **hosting/cPanel** tanpa perlu mengubah banyak konfigurasi.

---

## ✨ Apa yang Baru?

### 1. **Deteksi Environment Otomatis** 🤖
Aplikasi secara otomatis mendeteksi apakah berjalan di:
- **Localhost**: `localhost`, `127.0.0.1`, atau domain dengan `.local`
- **Hosting**: Domain publik

### 2. **Base URL Dinamis** 🌐
Base URL otomatis dihasilkan berdasarkan:
- Protocol (HTTP/HTTPS)
- Domain
- Path aplikasi

Tidak perlu hardcode URL lagi!

### 3. **Path Gambar & Upload Fleksibel** 🖼️
Semua path gambar dan upload menggunakan konstanta dinamis:
- `GAMBAR_URL` - URL untuk gambar statis
- `UPLOADS_URL` - URL untuk file upload
- `GAMBAR_DIR` - Path absolut ke folder gambar
- `UPLOADS_DIR` - Path absolut ke folder uploads

### 4. **Konfigurasi Database Terpisah** 🔐
Konfigurasi database terpisah untuk localhost dan hosting:
```php
if ($is_localhost) {
    // Konfigurasi localhost
} else {
    // Konfigurasi hosting (edit bagian ini saat deploy)
}
```

---

## 📁 Struktur File

```
sekolah/
├── config/
│   ├── database.php      ⭐ Konfigurasi database & environment
│   ├── helper.php        ⭐ Helper functions untuk path dinamis
│   └── .htaccess         🔒 Proteksi folder config
├── test.php              🧪 Test deployment
├── DEPLOYMENT_GUIDE.md   📖 Panduan deployment lengkap
└── README_DEPLOYMENT.md  📋 Ringkasan sistem (file ini)
```

---

## 🚀 Cara Menggunakan

### Di Localhost

1. Tidak perlu perubahan apa pun
2. Aplikasi otomatis menggunakan konfigurasi localhost
3. Base URL otomatis: `http://localhost/sekolah`

### Di Hosting

1. **Upload semua file** ke hosting
2. **Buat database** di cPanel
3. **Import database** dari localhost
4. **Edit** `config/database.php` di bagian hosting:
   ```php
   } else {
       // KONFIGURASI HOSTING/cPanel
       define('DB_HOST', 'localhost');
       define('DB_USER', 'usercp_username');     // Ganti!
       define('DB_PASS', 'password_database');    // Ganti!
       define('DB_NAME', 'usercp_nama_database');  // Ganti!
   }
   ```
5. **Test** dengan mengakses `https://domain.com/test.php`
6. **Selesai!** Hapus file `test.php` setelah testing

---

## 🔧 Helper Functions

### base_url($path = '')
Mendapatkan base URL aplikasi:
```php
<a href="<?php echo base_url('admin'); ?>">Admin Panel</a>
// Output: https://domain.com/admin
```

### gambar_url($filename)
Mendapatkan URL gambar:
```php
<img src="<?php echo gambar_url('header.jpg'); ?>" alt="Header">
// Output: https://domain.com/gambar/header.jpg
```

### upload_url($filename)
Mendapatkan URL file upload:
```php
<img src="<?php echo upload_url('berita1.jpg'); ?>" alt="Berita">
// Output: https://domain.com/uploads/berita1.jpg
```

### redirect($url)
Redirect ke URL tertentu:
```php
redirect('admin/berita');
// Redirect ke: https://domain.com/admin/berita
```

### Lihat Semua Function
Lihat file `config/helper.php` untuk semua fungsi yang tersedia.

---

## 📊 Checklist Deployment

### Persiapan di Localhost
- [ ] Export database dari phpMyAdmin
- [ ] Backup semua file dan folder
- [ ] Catat username & password database hosting

### Di Hosting
- [ ] Upload semua file ke `public_html`
- [ ] Buat database baru di cPanel
- [ ] Import database ke hosting
- [ ] Edit `config/database.php` dengan kredensial hosting
- [ ] Set permission folder `uploads/` (755 atau 777)
- [ ] Akses `https://domain.com/test.php`
- [ ] Verifikasi semua test berhasil (✅)
- [ ] Test login admin panel
- [ ] Test CRUD (Create, Read, Update, Delete)
- [ ] Test upload gambar
- [ ] Hapus file `test.php`

---

## 🔒 Keamanan

### File yang Sudah Diamankan
1. **config/.htaccess** - Folder config tidak bisa diakses langsung
2. **Error handling** - Error detail hanya ditampilkan di localhost
3. **Password default** - Ganti password admin dan database

### Best Practices
- Selalu gunakan HTTPS (SSL)
- Ganti password admin default
- Backup database secara berkala
- Hapus file `test.php` setelah deployment
- Update PHP dan MySQL ke versi terbaru

---

## 🐛 Troubleshooting

### Database Connection Failed
**Solusi:**
- Cek konfigurasi di `config/database.php`
- Pastikan database name, username, dan password benar
- Pastikan user database memiliki privileges

### Gambar Tidak Tampil
**Solusi:**
- Cek apakah folder `gambar/` dan `uploads/` ada
- Cek permission folder (755 atau 777)
- Pastikan file gambar sudah diupload

### 500 Internal Server Error
**Solusi:**
- Cek PHP version (minimal 7.4)
- Pastikan extension PHP aktif: PDO, PDO_MySQL, MBString, GD
- Cek file `.htaccess`

---

## 📚 Dokumentasi Lengkap

Untuk panduan deployment yang lebih detail, baca file:
- **DEPLOYMENT_GUIDE.md** - Panduan lengkap deployment ke hosting/cPanel

---

## ✅ Setelah Deployment Berhasil

1. **Hapus file test.php** dari server
2. **Ganti password admin** default
3. **Setup backup otomatis** database
4. **Enable HTTPS** dengan SSL certificate
5. **Test semua fitur** website

---

## 🎉 Keuntungan Sistem Ini

1. **Tanpa Hardcode URL** - Base URL otomatis di-generate
2. **Multi-Environment** - Satu codebase untuk localhost dan hosting
3. **Mudah Migrasi** - Hanya edit database credentials
4. **Path Dinamis** - Gambar dan file upload tetap tampil meskipun folder berubah
5. **Test Automation** - File test.php untuk verifikasi cepat
6. **Dokumentasi Lengkap** - Panduan deployment step-by-step

---

## 📞 Bantuan

Jika mengalami masalah:
1. Baca `DEPLOYMENT_GUIDE.md`
2. Cek error log: `public_html/error_log`
3. Jalankan `test.php` untuk verifikasi
4. Hubungi support hosting Anda

---

**Selamat! Website Anda sekarang siap untuk deployment dengan mudah! 🚀**