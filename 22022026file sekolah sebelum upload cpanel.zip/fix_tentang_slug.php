<?php
require_once 'config/database.php';

echo "<h2>🔧 Memperbaiki Slug 'Tentang Sekolah'</h2>";
echo "<hr>";

// Step 1: Show current state
echo "<h3>Langkah 1: Pengecekan Data Saat Ini</h3>";

$tentang = fetchAll("SELECT * FROM halaman WHERE slug = 'tentang'");
$tentang_sekolah = fetchAll("SELECT * FROM halaman WHERE slug = 'tentang-sekolah'");

echo "<p><strong>Data dengan slug 'tentang':</strong> " . count($tentang) . " record</p>";
if ($tentang) {
    echo "<ul>";
    foreach ($tentang as $row) {
        echo "<li>ID {$row['id']}: {$row['judul']} (Aktif: " . ($row['aktif'] ? 'Ya' : 'Tidak') . ")</li>";
    }
    echo "</ul>";
}

echo "<p><strong>Data dengan slug 'tentang-sekolah':</strong> " . count($tentang_sekolah) . " record</p>";
if ($tentang_sekolah) {
    echo "<ul>";
    foreach ($tentang_sekolah as $row) {
        echo "<li>ID {$row['id']}: {$row['judul']} (Aktif: " . ($row['aktif'] ? 'Ya' : 'Tidak') . ")</li>";
    }
    echo "</ul>";
}

echo "<hr>";

// Step 2: Fix the slug issue
echo "<h3>Langkah 2: Memperbaiki Slug</h3>";

try {
    // Delete ALL records with slug 'tentang' or 'tentang-sekolah'
    echo "<p>Menghapus semua data lama dengan slug 'tentang' dan 'tentang-sekolah'...</p>";
    $stmt = $pdo->prepare("DELETE FROM halaman WHERE slug IN ('tentang', 'tentang-sekolah')");
    $stmt->execute();
    $deleted_count = $stmt->rowCount();
    echo "<p style='color: green;'>✓ Berhasil menghapus {$deleted_count} record lama</p>";
    
    // Insert new clean record with correct slug
    echo "<p>Menyisipkan data baru dengan slug 'tentang'...</p>";
    
    $isi = '<h2>Tentang SLB Rumah Kita Batam</h2>
<p>SLB Rumah Kita Batam adalah sekolah luar biasa yang berdedikasi untuk memberikan pendidikan berkualitas bagi anak-anak berkebutuhan khusus. Berdiri sejak tahun 2015, sekolah kami telah melayani ratusan siswa dengan berbagai kebutuhan pendidikan khusus.</p>

<h3>Visi</h3>
<p>Menjadi sekolah luar biasa terdepan yang inklusif dan berdaya saing di tingkat nasional.</p>

<h3>Misi</h3>
<ol>
    <li>Menyelenggarakan pendidikan berkualitas bagi anak berkebutuhan khusus</li>
    <li>Mengembangkan potensi siswa secara optimal</li>
    <li>Membangun kerjasama dengan berbagai pihak</li>
    <li>Menciptakan lingkungan belajar yang inklusif</li>
</ol>

<p>Kami berkomitmen untuk memberikan pelayanan terbaik dengan pendekatan individual bagi setiap siswa, mengembangkan potensi mereka secara optimal, dan mempersiapkan mereka untuk menjadi mandiri dan produktif.</p>';

    $stmt = $pdo->prepare("INSERT INTO halaman (judul, slug, isi, urutan, aktif, icon) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->execute(['Tentang Sekolah', 'tentang', $isi, 1, 1, 'fa-school']);
    
    echo "<p style='color: green;'>✓ Berhasil menyisipkan data baru dengan slug 'tentang'</p>";
    
    // Verify the fix
    echo "<hr>";
    echo "<h3>Langkah 3: Verifikasi Perbaikan</h3>";
    
    $verify = fetchOne("SELECT * FROM halaman WHERE slug = 'tentang'");
    
    if ($verify) {
        echo "<p style='color: green;'><strong>✓ SUKSES!</strong> Data 'Tentang Sekolah' sekarang memiliki slug yang benar.</p>";
        echo "<table border='1' cellpadding='10' style='border-collapse: collapse;'>";
        echo "<tr><th>Kolom</th><th>Nilai</th></tr>";
        echo "<tr><td><strong>ID</strong></td><td>" . htmlspecialchars($verify['id']) . "</td></tr>";
        echo "<tr><td><strong>Judul</strong></td><td>" . htmlspecialchars($verify['judul']) . "</td></tr>";
        echo "<tr><td><strong>Slug</strong></td><td><code style='color: green;'>" . htmlspecialchars($verify['slug']) . "</code></td></tr>";
        echo "<tr><td><strong>Aktif</strong></td><td>" . ($verify['aktif'] ? 'Ya' : 'Tidak') . "</td></tr>";
        echo "</table>";
        
        echo "<hr>";
        echo "<div style='background: #d4edda; color: #155724; padding: 15px; border-radius: 5px;'>";
        echo "<strong>✅ Perbaikan Selesai!</strong><br><br>";
        echo "Sekarang halaman <code>index.php</code> seharusnya dapat menampilkan konten 'Tentang Sekolah' dengan benar.<br>";
        echo "Silakan refresh halaman <a href='index.php'>index.php</a> untuk melihat hasilnya.";
        echo "</div>";
    } else {
        echo "<p style='color: red;'>❌ Gagal memverifikasi data!</p>";
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'><strong>ERROR:</strong> " . $e->getMessage() . "</p>";
}

echo "<hr>";
echo "<p><a href='index.php' style='padding: 10px 20px; background: #28a745; color: white; text-decoration: none; border-radius: 5px;'>Kembali ke Beranda</a></p>";
echo "&nbsp;";
echo "<a href='check_tentang_data.php' style='padding: 10px 20px; background: #17a2b8; color: white; text-decoration: none; border-radius: 5px;'>Cek Lagi Data</a></p>";
?>