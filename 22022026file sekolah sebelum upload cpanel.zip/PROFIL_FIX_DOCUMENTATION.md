# Dokumentasi Perbaikan Sistem Profil Sekolah

## Masalah
File `admin/profil.php` sebelumnya menggunakan tabel `halaman` dengan slug `'tentang'` dan `'visi-misi'` untuk menyimpan data profil sekolah. Ini menyebabkan masalah:
- ❌ Data profil bisa hilang jika admin mengedit/hapus halaman di `admin/halaman.php`
- ❌ Tidak ada pemisahan yang jelas antara halaman umum dan data profil sekolah
- ❌ Rentan terhadap error saat mengelola halaman lain

## Solusi
Membuat tabel terpisah `profil_sekolah` untuk menyimpan data profil sekolah secara khusus.

## Struktur Tabel Baru
```sql
CREATE TABLE profil_sekolah (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tentang TEXT NOT NULL,
    visi_misi TEXT NOT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

## File yang Diupdate

### 1. `admin/profil.php`
- ✅ Mengubah query untuk menggunakan tabel `profil_sekolah`
- ✅ Menambahkan logic untuk insert/update data
- ✅ Memperbaiki bug pada textarea (menghapus `['isi']` yang tidak perlu)

**Perubahan utama:**
```php
// Sebelumnya
$tentang = fetchOne("SELECT * FROM halaman WHERE slug = 'tentang'");
$visi_misi = fetchOne("SELECT * FROM halaman WHERE slug = 'visi-misi'");

// Sekarang
$profil = fetchOne("SELECT * FROM profil_sekolah LIMIT 1");
$tentang = $profil ? $profil['tentang'] : '';
$visi_misi = $profil ? $profil['visi_misi'] : '';
```

### 2. `profil.php` (halaman publik)
- ✅ Mengubah query untuk mengambil data dari tabel `profil_sekolah`
- ✅ Menjaga format output yang sama agar tampilan tidak berubah

**Perubahan utama:**
```php
// Sebelumnya
$tentang = fetchOne("SELECT * FROM halaman WHERE slug = 'tentang'");
$visi_misi = fetchOne("SELECT * FROM halaman WHERE slug = 'visi-misi'");

// Sekarang
$profil = fetchOne("SELECT * FROM profil_sekolah LIMIT 1");
$tentang = $profil ? ['isi' => $profil['tentang']] : null;
$visi_misi = $profil ? ['isi' => $profil['visi_misi']] : null;
```

## Cara Setup

### Langkah 1: Jalankan Setup Database
Buka browser dan akses:
```
http://localhost/sekolah/create_profil_table.php
```

File ini akan:
1. Membuat tabel `profil_sekolah` jika belum ada
2. Memindahkan data dari tabel `halaman` jika ada
3. Menggunakan data default jika tidak ada data sama sekali

### Langkah 2: Verifikasi
1. Login ke admin panel
2. Buka menu "Profil" di `admin/profil.php`
3. Pastikan data "Tentang Sekolah" dan "Visi & Misi" sudah terisi

### Langkah 3: Edit Profil
1. Di halaman admin profil, edit konten sesuai kebutuhan
2. Gunakan CKEditor untuk format teks
3. Klik "Simpan Perubahan"
4. Data akan tersimpan di tabel `profil_sekolah`

## Keuntungan Perbaikan Ini

✅ **Data Aman**: Data profil tersimpan di tabel terpisah, tidak akan terpengaruh saat mengedit/hapus halaman lain

✅ **Struktur Lebih Baik**: Pemisahan yang jelas antara halaman umum dan data profil sekolah

✅ **Mudah Dikelola**: Admin tidak perlu khawatir data profil hilang saat mengelola halaman

✅ **Migrasi Otomatis**: Data lama dari tabel `halaman` akan otomatis dipindahkan

✅ **Fallback**: Jika tidak ada data, akan menggunakan data default yang sudah disiapkan

## Catatan Pentual

- Tabel `halaman` masih tetap digunakan untuk mengelola halaman-halaman lainnya (Program, Berita, Galeri, dll)
- Hanya data profil sekolah yang dipindahkan ke tabel `profil_sekolah`
- File `create_profil_table.php` aman untuk dijalankan berulang kali (menggunakan `CREATE TABLE IF NOT EXISTS`)

## Troubleshooting

### Jika data tidak muncul di halaman admin profil
1. Pastikan tabel `profil_sekolah` sudah dibuat dengan menjalankan `create_profil_table.php`
2. Cek database apakah ada data di tabel `profil_sekolah`
3. Pastikan koneksi database berjalan normal

### Jika ingin memulai ulang (reset data)
```sql
TRUNCATE TABLE profil_sekolah;
```
Kemudian jalankan ulang `create_profil_table.php`

## File Tambahan
- `create_profil_table.php` - Script untuk membuat tabel dan memindahkan data
- `create_profil_table.sql` - File SQL mentah (opsional, bisa dijalankan manual jika perlu)

## Status Perbaikan
✅ Selesai - Sistem profil sekolah sudah dipisahkan dan aman dari kehilangan data