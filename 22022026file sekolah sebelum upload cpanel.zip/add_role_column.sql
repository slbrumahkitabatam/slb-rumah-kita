-- ========================================
-- MIGRATION: Add Role Column to Users Table
-- ========================================
-- This script adds a 'role' column to the users table
-- and sets appropriate default values for existing users

-- Add role column with default value 'guru'
ALTER TABLE users ADD COLUMN role ENUM('admin', 'guru') DEFAULT 'guru' AFTER nama;

-- Update existing users: user with id=1 becomes admin, others become guru
UPDATE users SET role = 'admin' WHERE id = 1;
UPDATE users SET role = 'guru' WHERE id > 1;

-- Add index for role column for better query performance
CREATE INDEX idx_users_role ON users(role);

-- Verify the changes
SELECT id, username, nama, role FROM users;