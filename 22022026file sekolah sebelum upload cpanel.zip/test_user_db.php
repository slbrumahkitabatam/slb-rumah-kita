<?php
session_start();
require 'config/database.php';
require 'config/helper.php';

echo "<h1>Test Database User</h1>";

// Test koneksi
echo "<h2>1. Koneksi Database:</h2>";
if (isset($pdo)) {
    echo "<p style='color: green;'>✓ Koneksi berhasil!</p>";
    echo "<p>Database: " . DB_NAME . "</p>";
} else {
    echo "<p style='color: red;'>✗ Koneksi gagal!</p>";
}

// Test cek tabel users
echo "<h2>2. Cek Tabel Users:</h2>";
try {
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM users");
    $result = $stmt->fetch();
    echo "<p style='color: green;'>✓ Tabel users ada!</p>";
    echo "<p>Total user: " . $result['total'] . "</p>";
} catch(PDOException $e) {
    echo "<p style='color: red;'>✗ Tabel users tidak ada!</p>";
    echo "<p>Error: " . $e->getMessage() . "</p>";
}

// Test ambil data users
echo "<h2>3. Data Users:</h2>";
try {
    $users = fetchAll("SELECT * FROM users");
    if (!empty($users)) {
        echo "<p style='color: green;'>✓ Data users berhasil diambil!</p>";
        echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
        echo "<tr><th>ID</th><th>Username</th><th>Nama</th><th>Created At</th></tr>";
        foreach ($users as $user) {
            echo "<tr>";
            echo "<td>" . $user['id'] . "</td>";
            echo "<td>" . htmlspecialchars($user['username']) . "</td>";
            echo "<td>" . htmlspecialchars($user['nama']) . "</td>";
            echo "<td>" . $user['created_at'] . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p style='color: orange;'>⚠ Tidak ada data users!</p>";
    }
} catch(PDOException $e) {
    echo "<p style='color: red;'>✗ Gagal mengambil data users!</p>";
    echo "<p>Error: " . $e->getMessage() . "</p>";
}

// Test cek session
echo "<h2>4. Cek Session:</h2>";
if (isset($_SESSION['user_id'])) {
    echo "<p style='color: green;'>✓ User login!</p>";
    echo "<p>User ID: " . $_SESSION['user_id'] . "</p>";
    if (isset($_SESSION['role'])) {
        echo "<p>Role: " . $_SESSION['role'] . "</p>";
    }
} else {
    echo "<p style='color: red;'>✗ User belum login!</p>";
    echo "<p><a href='admin/login.php'>Login di sini</a></p>";
}

echo "<hr>";
echo "<h2>5. Test Helper Functions:</h2>";
echo "<p>Test sanitize(): " . sanitize('<script>alert("test")</script>') . "</p>";
echo "<p>Test tgl_singkat(): " . tgl_singkat('2025-12-31') . "</p>";
?>