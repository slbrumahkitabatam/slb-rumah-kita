<?php
/**
 * File untuk verifikasi deployment ke hosting
 * 
 * File ini digunakan untuk mengecek apakah:
 * 1. Koneksi database berhasil
 * 2. Base URL dan Base Path sudah benar
 * 3. Folder yang diperlukan ada
 * 4. PHP version sesuai
 * 5. Database tables sudah ada
 * 
 * Setelah testing selesai, HAPUS file ini dari server!
 */

// Load konfigurasi
require 'config/database.php';

// Mulai session untuk testing
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test Deployment - SLB Rumah Kita</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 20px;
        }
        .container {
            max-width: 1000px;
            margin: 0 auto;
            background: white;
            border-radius: 10px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
            overflow: hidden;
        }
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            text-align: center;
        }
        .header h1 {
            font-size: 2em;
            margin-bottom: 10px;
        }
        .header p {
            opacity: 0.9;
        }
        .content {
            padding: 30px;
        }
        .section {
            margin-bottom: 30px;
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            overflow: hidden;
        }
        .section-header {
            background: #f5f5f5;
            padding: 15px 20px;
            border-bottom: 1px solid #e0e0e0;
            font-weight: bold;
            color: #333;
            font-size: 1.1em;
        }
        .section-content {
            padding: 20px;
        }
        .item {
            padding: 10px;
            margin: 5px 0;
            border-radius: 5px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .warning {
            background: #fff3cd;
            color: #856404;
            border: 1px solid #ffeeba;
        }
        .info {
            background: #d1ecf1;
            color: #0c5460;
            border: 1px solid #bee5eb;
        }
        .icon {
            font-size: 1.5em;
            width: 30px;
            text-align: center;
        }
        .code {
            background: #f4f4f4;
            padding: 10px;
            border-radius: 5px;
            font-family: 'Courier New', monospace;
            font-size: 0.9em;
            margin: 10px 0;
            word-break: break-all;
        }
        .alert {
            background: #fff3cd;
            border-left: 4px solid #ffc107;
            padding: 15px;
            margin: 20px 0;
            border-radius: 5px;
        }
        .alert strong {
            color: #856404;
        }
        .table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        .table th, .table td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #e0e0e0;
        }
        .table th {
            background: #f5f5f5;
            font-weight: bold;
        }
        .footer {
            background: #f5f5f5;
            padding: 20px;
            text-align: center;
            color: #666;
            font-size: 0.9em;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🧪 Test Deployment</h1>
            <p>Verifikasi konfigurasi aplikasi SLB Rumah Kita</p>
        </div>
        
        <div class="content">
            
            <!-- Database Connection -->
            <div class="section">
                <div class="section-header">
                    🔌 1. Koneksi Database
                </div>
                <div class="section-content">
                    <?php
                    $db_status = 'success';
                    try {
                        $stmt = $pdo->query("SELECT COUNT(*) as total FROM users");
                        $result = $stmt->fetch();
                        echo '<div class="item success">';
                        echo '<span class="icon">✅</span>';
                        echo '<span><strong>Database Connected!</strong> - Found ' . $result['total'] . ' users in database</span>';
                        echo '</div>';
                        
                        // Cek database info
                        $db_info = $pdo->query("SELECT DATABASE() as db_name, VERSION() as version")->fetch();
                        echo '<div class="item info">';
                        echo '<span class="icon">ℹ️</span>';
                        echo '<span>Database Name: <strong>' . htmlspecialchars($db_info['db_name']) . '</strong></span>';
                        echo '</div>';
                        echo '<div class="item info">';
                        echo '<span class="icon">ℹ️</span>';
                        echo '<span>MySQL Version: <strong>' . htmlspecialchars($db_info['version']) . '</strong></span>';
                        echo '</div>';
                    } catch (PDOException $e) {
                        $db_status = 'error';
                        echo '<div class="item error">';
                        echo '<span class="icon">❌</span>';
                        echo '<span><strong>Database Connection Failed!</strong></span>';
                        echo '</div>';
                        echo '<div class="code">Error: ' . htmlspecialchars($e->getMessage()) . '</div>';
                    }
                    ?>
                </div>
            </div>

            <!-- Base URL & Path -->
            <div class="section">
                <div class="section-header">
                    🌐 2. Base URL dan Base Path
                </div>
                <div class="section-content">
                    <div class="item info">
                        <span class="icon">ℹ️</span>
                        <div>
                            <strong>BASE_URL:</strong><br>
                            <div class="code"><?php echo htmlspecialchars(BASE_URL); ?></div>
                        </div>
                    </div>
                    <div class="item info">
                        <span class="icon">ℹ️</span>
                        <div>
                            <strong>BASE_PATH:</strong><br>
                            <div class="code"><?php echo htmlspecialchars(BASE_PATH); ?></div>
                        </div>
                    </div>
                    <div class="item info">
                        <span class="icon">ℹ️</span>
                        <div>
                            <strong>Current Environment:</strong> 
                            <?php 
                            echo '<span style="font-weight: bold; color: ' . ($is_localhost ? '#28a745' : '#007bff') . '">';
                            echo $is_localhost ? 'LOCALHOST' : 'HOSTING';
                            echo '</span>';
                            ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Folder Check -->
            <div class="section">
                <div class="section-header">
                    📁 3. Cek Folder
                </div>
                <div class="section-content">
                    <?php
                    $folders = [
                        'uploads' => 'Folder untuk upload file',
                        'gambar' => 'Folder untuk gambar statis',
                        'config' => 'Folder konfigurasi',
                        'admin' => 'Folder admin panel',
                        'includes' => 'Folder includes'
                    ];
                    
                    foreach ($folders as $folder => $desc) {
                        $path = BASE_PATH . '/' . $folder;
                        if (is_dir($path)) {
                            echo '<div class="item success">';
                            echo '<span class="icon">✅</span>';
                            echo '<span><strong>' . $folder . '/</strong> - ' . $desc . '</span>';
                            echo '</div>';
                        } else {
                            echo '<div class="item error">';
                            echo '<span class="icon">❌</span>';
                            echo '<span><strong>' . $folder . '/</strong> - NOT FOUND!</span>';
                            echo '</div>';
                        }
                    }
                    ?>
                </div>
            </div>

            <!-- PHP Configuration -->
            <div class="section">
                <div class="section-header">
                    ⚙️ 4. Konfigurasi PHP
                </div>
                <div class="section-content">
                    <?php
                    $php_version = phpversion();
                    $php_min = '7.4';
                    $php_status = version_compare($php_version, $php_min, '>=') ? 'success' : 'warning';
                    
                    echo '<div class="item ' . $php_status . '">';
                    echo '<span class="icon">' . ($php_status == 'success' ? '✅' : '⚠️') . '</span>';
                    echo '<span>PHP Version: <strong>' . $php_version . '</strong> (Minimal: ' . $php_min . ')</span>';
                    echo '</div>';
                    
                    // Cek extensions
                    $required_extensions = ['pdo', 'pdo_mysql', 'mbstring', 'json', 'gd'];
                    foreach ($required_extensions as $ext) {
                        $loaded = extension_loaded($ext);
                        echo '<div class="item ' . ($loaded ? 'success' : 'error') . '">';
                        echo '<span class="icon">' . ($loaded ? '✅' : '❌') . '</span>';
                        echo '<span>Extension <strong>' . $ext . '</strong>: ' . ($loaded ? 'LOADED' : 'NOT LOADED') . '</span>';
                        echo '</div>';
                    }
                    
                    // Cek upload limits
                    echo '<div class="item info">';
                    echo '<span class="icon">ℹ️</span>';
                    echo '<span>upload_max_filesize: <strong>' . ini_get('upload_max_filesize') . '</strong></span>';
                    echo '</div>';
                    echo '<div class="item info">';
                    echo '<span class="icon">ℹ️</span>';
                    echo '<span>post_max_size: <strong>' . ini_get('post_max_size') . '</strong></span>';
                    echo '</div>';
                    ?>
                </div>
            </div>

            <!-- Database Tables -->
            <div class="section">
                <div class="section-header">
                    📊 5. Database Tables
                </div>
                <div class="section-content">
                    <?php
                    if ($db_status == 'success') {
                        try {
                            $stmt = $pdo->query("SHOW TABLES");
                            $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
                            
                            echo '<table class="table">';
                            echo '<thead><tr><th>No</th><th>Table Name</th><th>Status</th></tr></thead>';
                            echo '<tbody>';
                            
                            $expected_tables = ['users', 'berita', 'galeri', 'halaman', 'guru', 'pengaturan', 'tampilan'];
                            
                            foreach ($tables as $index => $table) {
                                $expected = in_array($table, $expected_tables);
                                echo '<tr>';
                                echo '<td>' . ($index + 1) . '</td>';
                                echo '<td>' . htmlspecialchars($table) . '</td>';
                                echo '<td>' . ($expected ? '✅ Expected' : '⚠️ Additional') . '</td>';
                                echo '</tr>';
                            }
                            
                            echo '</tbody></table>';
                            
                            // Cek tabel yang hilang
                            $missing = array_diff($expected_tables, $tables);
                            if (!empty($missing)) {
                                echo '<div class="item warning" style="margin-top: 15px;">';
                                echo '<span class="icon">⚠️</span>';
                                echo '<span><strong>Missing Tables:</strong> ' . implode(', ', $missing) . '</span>';
                                echo '</div>';
                            }
                            
                        } catch (PDOException $e) {
                            echo '<div class="item error">';
                            echo '<span class="icon">❌</span>';
                            echo '<span>Error: ' . htmlspecialchars($e->getMessage()) . '</span>';
                            echo '</div>';
                        }
                    } else {
                        echo '<div class="item error">';
                        echo '<span class="icon">❌</span>';
                        echo '<span>Cannot check tables - database not connected</span>';
                        echo '</div>';
                    }
                    ?>
                </div>
            </div>

            <!-- Path Configuration -->
            <div class="section">
                <div class="section-header">
                    🖼️ 6. Path Gambar dan Upload
                </div>
                <div class="section-content">
                    <div class="item info">
                        <span class="icon">ℹ️</span>
                        <div>
                            <strong>GAMBAR_DIR:</strong><br>
                            <div class="code"><?php echo htmlspecialchars(GAMBAR_DIR); ?></div>
                        </div>
                    </div>
                    <div class="item info">
                        <span class="icon">ℹ️</span>
                        <div>
                            <strong>UPLOADS_DIR:</strong><br>
                            <div class="code"><?php echo htmlspecialchars(UPLOADS_DIR); ?></div>
                        </div>
                    </div>
                    <div class="item info">
                        <span class="icon">ℹ️</span>
                        <div>
                            <strong>GAMBAR_URL:</strong><br>
                            <div class="code"><?php echo htmlspecialchars(GAMBAR_URL); ?></div>
                        </div>
                    </div>
                    <div class="item info">
                        <span class="icon">ℹ️</span>
                        <div>
                            <strong>UPLOADS_URL:</strong><br>
                            <div class="code"><?php echo htmlspecialchars(UPLOADS_URL); ?></div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Warning -->
            <div class="alert">
                <strong>⚠️ PENTING!</strong>
                <p>Setelah testing selesai dan semua berjalan normal, <strong>HAPUS file test.php ini dari server</strong> untuk alasan keamanan!</p>
                <p>File ini memberikan informasi detail tentang konfigurasi server Anda yang bisa dimanfaatkan oleh pihak yang tidak bertanggung jawab.</p>
            </div>

            <!-- Next Steps -->
            <div class="section">
                <div class="section-header">
                    📝 Langkah Selanjutnya
                </div>
                <div class="section-content">
                    <?php if ($db_status == 'success'): ?>
                        <p>✅ Semua test telah selesai. Anda bisa:</p>
                        <ul style="margin-left: 20px; margin-top: 10px;">
                            <li>Akses website utama: <a href="<?php echo BASE_URL; ?>" target="_blank" style="color: #667eea;"><?php echo BASE_URL; ?></a></li>
                            <li>Login admin: <a href="<?php echo base_url('admin'); ?>" target="_blank" style="color: #667eea;"><?php echo base_url('admin'); ?></a></li>
                            <li>Hapus file test.php ini dari server</li>
                        </ul>
                    <?php else: ?>
                        <p>❌ Masih ada error yang perlu diperbaiki. Cek bagian yang berwarna merah di atas dan perbaiki konfigurasi Anda.</p>
                    <?php endif; ?>
                </div>
            </div>

        </div>
        
        <div class="footer">
            <p>Test Deployment - SLB Rumah Kita</p>
            <p>Generated: <?php echo date('Y-m-d H:i:s'); ?></p>
        </div>
    </div>
</body>
</html>