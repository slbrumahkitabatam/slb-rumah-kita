-- ========================================
-- DATABASE SEKOLAH SLB RUMAH KITA BATAM
-- Complete Database Schema with Sample Data
-- ========================================

-- Create Database


-- ========================================
-- TABEL USERS (ADMIN)
-- ========================================
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    nama VARCHAR(100) NOT NULL,
    role ENUM('admin', 'guru') DEFAULT 'guru',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ========================================
-- TABEL BERITA
-- ========================================
CREATE TABLE IF NOT EXISTS berita (
    id INT AUTO_INCREMENT PRIMARY KEY,
    judul VARCHAR(255) NOT NULL,
    slug VARCHAR(255) NOT NULL UNIQUE,
    isi TEXT NOT NULL,
    gambar VARCHAR(255),
    tanggal DATE NOT NULL,
    penulis VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ========================================
-- TABEL GALERI
-- ========================================
CREATE TABLE IF NOT EXISTS galeri (
    id INT AUTO_INCREMENT PRIMARY KEY,
    judul VARCHAR(255) NOT NULL,
    deskripsi TEXT,
    gambar VARCHAR(255) NOT NULL,
    tanggal DATE NOT NULL,
    kategori VARCHAR(100) NOT NULL DEFAULT 'kegiatan',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ========================================
-- TABEL HALAMAN (Profil, Visi Misi, dll)
-- ========================================
CREATE TABLE IF NOT EXISTS halaman (
    id INT AUTO_INCREMENT PRIMARY KEY,
    judul VARCHAR(255) NOT NULL,
    slug VARCHAR(255) NOT NULL UNIQUE,
    isi TEXT NOT NULL,
    urutan INT DEFAULT 0,
    aktif TINYINT(1) DEFAULT 1,
    icon VARCHAR(50),
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ========================================
-- TABEL GURU & STAF
-- ========================================
CREATE TABLE IF NOT EXISTS guru (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    jabatan VARCHAR(100) NOT NULL,
    foto VARCHAR(255),
    deskripsi TEXT,
    urutan INT DEFAULT 0,
    aktif TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ========================================
-- TABEL PENGATURAN SEKOLAH
-- ========================================
CREATE TABLE IF NOT EXISTS pengaturan (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama_sekolah VARCHAR(255) NOT NULL DEFAULT 'SLB Rumah Kita Batam',
    alamat TEXT,
    telepon VARCHAR(50),
    email VARCHAR(100),
    logo VARCHAR(255),
    maps_embed TEXT,
    facebook VARCHAR(255),
    instagram VARCHAR(255),
    youtube VARCHAR(255),
    whatsapp VARCHAR(50),
    meta_title VARCHAR(255),
    meta_description TEXT,
    meta_keywords TEXT,
    footer_text TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ========================================
-- TABEL TAMPILAN WEBSITE
-- ========================================
CREATE TABLE IF NOT EXISTS tampilan (
    id INT AUTO_INCREMENT PRIMARY KEY,
    logo VARCHAR(255),
    favicon VARCHAR(255),
    background_beranda VARCHAR(255),
    background_halaman VARCHAR(255),
    background_footer VARCHAR(255),
    warna_utama VARCHAR(7) DEFAULT '#4A90E2',
    warna_teks VARCHAR(7) DEFAULT '#333333',
    font_website VARCHAR(50) DEFAULT 'Poppins',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ========================================
-- DATA SAMPLE - USERS
-- ========================================
-- Password: admin123
INSERT INTO users (username, password, nama, role) VALUES 
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Administrator', 'admin'),
('guru', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Guru Admin', 'guru');

-- ========================================
-- DATA SAMPLE - BERITA
-- ========================================
INSERT INTO berita (judul, slug, isi, gambar, tanggal, penulis) VALUES 
('Pembukaan Program Pelatihan Keterampilan Vokasi untuk Siswa SLB', 'pembukaan-program-pelatihan-keterampilan-vokasi-untuk-siswa-slb', '<p>SLB Rumah Kita Batam dengan bangga mengumumkan pembukaan program pelatihan keterampilan vokasi baru untuk siswa-siswi kami. Program ini dirancang khusus untuk mengembangkan potensi siswa dalam berbagai bidang keterampilan.</p><p>Program pelatihan ini mencakup:</p><ul><li>Keterampilan komputer dan IT</li><li>Kerajinan tangan dan seni</li><li>Keterampilan tata boga</li><li>Keterampilan otomotif dasar</li></ul><p>Kami berharap program ini dapat membantu siswa kami menjadi lebih mandiri dan siap menghadapi tantangan di masa depan.</p>', 'Pembukaan Program Pelatihan Keterampilan Vokasi untuk Siswa SLB.jpeg', '2025-01-10', 'Administrator'),

('Perayaan Hari Penyandang Disabilitas Internasional di SLB Rumah Kita', 'perayaan-hari-penyandang-disabilitas-internasional-di-slb-rumah-kita', '<p>SLB Rumah Kita Batam merayakan Hari Penyandang Disabilitas Internasional dengan berbagai kegiatan yang menarik dan bermakna. Acara ini dihadiri oleh seluruh siswa, guru, staf, serta orang tua siswa.</p><p>Acara yang diselenggarakan antara lain:</p><ul><li>Pentas seni siswa</li><li>Lomba kreativitas</li><li>Seminar parenting</li><li>Bazaar produk kerajinan siswa</li></ul><p>Melalui perayaan ini, kami ingin meningkatkan kesadaran masyarakat akan pentingnya inklusi dan kesetaraan bagi penyandang disabilitas.</p>', 'Perayaan Hari Penyandang Disabilitas Internasional di SLB Rumah Kita.webp', '2025-03-15', 'Administrator'),

('Kunjungan Studi Banding dari SLB Se-Kota Batam', 'kunjungan-studi-banding-dari-slb-se-kota-batam', '<p>SLB Rumah Kita Batam menerima kunjungan studi banding dari berbagai SLB se-Kota Batam. Kunjungan ini bertujuan untuk berbagi pengalaman dan praktik terbaik dalam pendidikan khusus.</p><p>Agenda kunjungan meliputi:</p><ul><li>Pembukaan dan sambutan kepala sekolah</li><li>Observasi kelas</li><li>Diskusi kurikulum</li><li>Presentasi program unggulan</li></ul><p>Kami sangat mengapresiasi kunjungan ini dan berharap dapat terus berkolaborasi untuk kemajuan pendidikan khusus di Batam.</p>', 'Kunjungan Studi Banding.jpeg', '2025-02-20', 'Administrator'),

('Kunjungan Edukasi ke Museum Batam untuk Siswa SLB', 'kunjungan-edukasi-ke-museum-batam-untuk-siswa-slb', '<p>Siswa-siswi SLB Rumah Kita Batam melakukan kunjungan edukasi ke Museum Batam. Kunjungan ini merupakan bagian dari program pembelajaran luar kelas yang bertujuan untuk mengenalkan sejarah dan budaya Batam kepada siswa.</p><p>Selama kunjungan, siswa melakukan berbagai aktivitas:</p><ul><li>Observasi koleksi museum</li><li>Diskusi dengan pemandu museum</li><li>Kuis interaktif tentang sejarah</li><li>Dokumentasi pengalaman belajar</li></ul><p>Kunjungan ini sangat bermanfaat untuk mengembangkan wawasan siswa tentang sejarah daerah.</p>', 'Kunjungan Edukasi ke Museum Batam untuk Siswa SLB.jpeg', '2025-02-05', 'Administrator'),

('Siswa Kami Meraih Juara 1 Lomba Basket', 'siswa-kami-meraih-juara-1-lomba-basket', '<p>Prestasi membanggakan kembali diraih oleh siswa SLB Rumah Kita Batam. Tim basket sekolah berhasil meraih juara 1 dalam turnamen basket tingkat kota yang diselenggarakan baru-baru ini.</p><p>Tim basket kami menunjukkan semangat juang yang luar biasa dan kerjasama tim yang solid. Kemenangan ini merupakan hasil dari latihan keras dan dedikasi siswa serta pelatih.</p><p>Selamat kepada tim basket SLB Rumah Kita Batam! Teruslah berprestasi!</p>', 'Juara Basket.jpeg', '2025-03-01', 'Guru Basket'),

('Wisuda Siswa Angkatan Tahun Ajaran 2024/2025', 'wisuda-siswa-angkatan-tahun-ajaran-2024-2025', '<p>SLB Rumah Kita Batam dengan bangga menyelenggarakan acara wisuda untuk siswa angkatan tahun ajaran 2024/2025. Acara wisuda ini dihadiri oleh orang tua siswa, guru, staf, serta undangan.</p><p>Sebanyak 25 siswa dari jenjang SDLB, SMPLB, dan SMALB berhasil menyelesaikan pendidikan mereka di SLB Rumah Kita Batam. Mereka diharapkan dapat melanjutkan ke tahap selanjutnya dengan bekal ilmu dan keterampilan yang telah diperoleh.</p><p>Selamat kepada para wisudawan dan wisudawati! Semoga sukses di masa depan.</p>', 'Wisuda Siswa.jpg', '2025-06-20', 'Administrator');

-- ========================================
-- DATA SAMPLE - GALERI
-- ========================================
INSERT INTO galeri (judul, deskripsi, gambar, tanggal, kategori) VALUES 
-- Kegiatan Belajar Mengajar
('Siswa Belajar Membaca', 'Siswa kelas SDLB sedang belajar membaca dengan metode yang menyenangkan', 'Siswa Belajar Membaca.jpeg', '2025-01-15', 'kbm'),
('Praktik Melukis', 'Kegiatan melukis siswa kelas SMALB dalam seni rupa', 'Praktik Melukis.jpeg', '2025-01-18', 'kbm'),
('Belajar Komputer', 'Siswa berlatih menggunakan komputer di lab komputer sekolah', 'Belajar Komputer.jpeg', '2025-01-20', 'kbm'),

-- Ekstrakurikuler
('Olahraga Basket', 'Tim basket sekolah sedang berlatih', 'Juara Basket.jpeg', '2025-02-01', 'eskul'),
('Seni Tari', 'Latihan tari tradisional siswi', 'lukis.jpg', '2025-02-03', 'eskul'),
('Paduan Suara', 'Latihan menyanyi paduan suara', 'lukis.jpg', '2025-02-05', 'eskul'),

-- Kegiatan Sekolah
('Perayaan Hari Kemerdekaan', 'Upacara peringatan Hari Kemerdekaan RI ke-80', 'Perayaan Hari Kemerdekaan.jpeg', '2025-08-17', 'kegiatan'),
('Ulang Tahun Sekolah', 'Perayaan ulang tahun ke-10 SLB Rumah Kita', 'Ulang Tahun Sekolah.jpeg', '2025-09-01', 'kegiatan'),
('Kunjungan Studi Banding', 'Kunjungan dari SLB se-Kota Batam', 'Kunjungan Studi Banding.jpeg', '2025-10-15', 'kegiatan'),
('Baksos Pengobatan Gratis', 'Bakti sosial pengobatan gratis untuk masyarakat', 'Baksos Pengobatan Gratis.jpg', '2025-11-20', 'kegiatan'),
('Wisuda Siswa', 'Wisuda siswa SMALB tahun ajaran 2024/2025', 'Wisuda Siswa.jpg', '2025-12-10', 'kegiatan'),

-- Fasilitas
('Ruang Kelas SDLB', 'Ruang kelas yang nyaman untuk pembelajaran', 'Tentang Sekolah1.jpg', '2025-01-01', 'fasilitas'),
('Laboratorium Komputer', 'Lab komputer lengkap dengan 20 unit', 'Belajar Komputer.jpeg', '2025-01-01', 'fasilitas'),
('Ruang Terapi', 'Ruang terapi untuk kebutuhan khusus siswa', 'Tentang Sekolah2.jpg', '2025-01-01', 'fasilitas'),
('Perpustakaan', 'Perpustakaan dengan koleksi buku lengkap', 'Tentang Sekolah3.jpg', '2025-01-01', 'fasilitas'),
('Lapangan Olahraga', 'Lapangan basket dan voli untuk kegiatan olahraga', 'Juara Basket.jpeg', '2025-01-01', 'fasilitas');

-- ========================================
-- DATA SAMPLE - HALAMAN
-- ========================================
INSERT INTO halaman (judul, slug, isi, urutan, aktif, icon) VALUES 
('Tentang Sekolah', 'tentang', '<h2>Tentang SLB Rumah Kita Batam</h2><p>SLB Rumah Kita Batam adalah sekolah luar biasa yang berdedikasi untuk memberikan pendidikan berkualitas bagi anak-anak berkebutuhan khusus. Berdiri sejak tahun 2015, sekolah kami telah melayani ratusan siswa dengan berbagai kebutuhan pendidikan khusus.</p><h3>Visi</h3><p>Menjadi sekolah luar biasa terdepan yang inklusif dan berdaya saing di tingkat nasional.</p><h3>Misi</h3><ol><li>Menyelenggarakan pendidikan berkualitas bagi anak berkebutuhan khusus</li><li>Mengembangkan potensi siswa secara optimal</li><li>Membangun kerjasama dengan berbagai pihak</li><li>Menciptakan lingkungan belajar yang inklusif</li></ol>', 1, 1, 'fa-school'),

('Visi & Misi', 'visi-misi', '<h3>Visi</h3><p>Menjadi sekolah luar biasa terdepan yang inklusif dan berdaya saing.</p><h3>Misi</h3><ol><li>Menyelenggarakan pendidikan berkualitas bagi anak berkebutuhan khusus</li><li>Mengembangkan potensi siswa secara optimal</li><li>Membangun kerjasama dengan berbagai pihak</li></ol>', 2, 1, 'fa-bullseye'),

('Program Pendidikan', 'program', '<h2>Program Pendidikan SLB Rumah Kita Batam</h2><p>Kami menyediakan berbagai program pendidikan yang disesuaikan dengan kebutuhan setiap siswa:</p><h3>SDLB (Sekolah Dasar Luar Biasa)</h3><p>Program pendidikan dasar untuk siswa dengan kebutuhan khusus pada tingkat dasar, mencakup mata pelajaran umum dengan penyesuaian kurikulum.</p><h3>SMPLB (Sekolah Menengah Pertama Luar Biasa)</h3><p>Program pendidikan menengah pertama dengan fokus pada pengembangan keterampilan akademik dan sosial.</p><h3>SMALB (Sekolah Menengah Atas Luar Biasa)</h3><p>Program pendidikan menengah atas dengan penekanan pada keterampilan vokasi dan persiapan untuk kemandirian.</p>', 3, 1, 'fa-graduation-cap'),

('Guru & Staf', 'guru', '<h2>Tim Pengajar SLB Rumah Kita Batam</h2><p>Tim pengajar kami terdiri dari profesional berpengalaman dalam pendidikan khusus. Setiap guru memiliki komitmen tinggi untuk membantu siswa mencapai potensi terbaik mereka.</p><p>Kami memiliki 15 guru aktif dengan berbagai spesialisasi:</p><ul><li>Guru kelas SDLB</li><li>Guru mata pelajaran SMPLB dan SMALB</li><li>Guru terapi</li><li>Guru BK</li></ul>', 4, 1, 'fa-users'),

('Kontak', 'kontak', '<h2>Hubungi Kami</h2><p>Silakan hubungi kami untuk informasi lebih lanjut tentang pendaftaran dan program pendidikan.</p><h3>Informasi Kontak</h3><p><strong>Alamat:</strong> Jl. Contoh No. 123, Batam<br><strong>Telepon:</strong> (0778) 1234567<br><strong>Email:</strong> info@rumahkita.sch.id<br><strong>WhatsApp:</strong> +62 812-3456-7890</p>', 5, 1, 'fa-envelope');

-- ========================================
-- DATA SAMPLE - GURU
-- ========================================
INSERT INTO guru (nama, jabatan, foto, deskripsi, urutan, aktif) VALUES 
('Drs. Budi Santoso', 'Kepala Sekolah', 'guru1.jpg', 'Berpengalaman dalam pendidikan khusus selama 20 tahun. Memiliki sertifikasi manajemen pendidikan inklusif.', 1, 1),
('Ibu Sari Wulandari, S.Pd', 'Wakil Kepala Sekolah', 'guru2.jpg', 'Ahli dalam kurikulum adaptif dan pembelajaran individual. Master Pendidikan Khusus dari Universitas Negeri Jakarta.', 2, 1),
('Ibu Rina Susanti, S.Psi', 'Guru Kelas SDLB', 'guru3.jpg', 'Spesialis dalam metode pembelajaran inklusif untuk anak dengan kebutuhan khusus. Sarjana Psikologi Pendidikan.', 3, 1),
('Bapak Ahmad Jaya', 'Guru Terapi', 'guru4.jpg', 'Terapis fisik dan okupasi berlisensi. Berpengalaman menangani berbagai kasus disabilitas fisik.', 4, 1),
('Ibu Dewi Kartika, S.Pd', 'Guru Bahasa Indonesia', 'guru5.jpg', 'Guru bahasa dengan pendekatan komunikatif untuk siswa berkebutuhan khusus. Lulusan Sastra Indonesia.', 5, 1);

-- ========================================
-- DATA SAMPLE - PENGATURAN
-- ========================================
INSERT INTO pengaturan (nama_sekolah, alamat, telepon, email, facebook, instagram, youtube, whatsapp, meta_title, meta_description, meta_keywords, footer_text) VALUES 
('SLB Rumah Kita Batam', 'Jl. Contoh No. 123, Batam, Kepulauan Riau', '(0778) 1234567', 'info@rumahkita.sch.id', 'https://facebook.com/slbrumahkitabatam', 'https://instagram.com/slbrumahkitabatam', 'https://youtube.com/slbrumahkitabatam', '+62 812-3456-7890', 'SLB Rumah Kita Batam - Sekolah Luar Biasa Terpercaya', 'SLB Rumah Kita Batam adalah sekolah luar biasa yang menyediakan pendidikan berkualitas bagi anak berkebutuhan khusus di Batam.', 'SLB Rumah Kita Batam, sekolah luar biasa, pendidikan khusus, SDLB, SMPLB, SMALB, Batam', '© 2025 SLB Rumah Kita Batam. Seluruh hak cipta dilindungi.');

-- ========================================
-- DATA SAMPLE - TAMPILAN
-- ========================================
INSERT INTO tampilan (warna_utama, warna_teks, font_website) VALUES 
('#4A90E2', '#333333', 'Poppins');

-- ========================================
-- INDEXING FOR PERFORMANCE
-- ========================================
CREATE INDEX idx_berita_slug ON berita(slug);
CREATE INDEX idx_berita_tanggal ON berita(tanggal);
CREATE INDEX idx_galeri_kategori ON galeri(kategori);
CREATE INDEX idx_galeri_tanggal ON galeri(tanggal);
CREATE INDEX idx_halaman_slug ON halaman(slug);
CREATE INDEX idx_halaman_aktif ON halaman(aktif);
CREATE INDEX idx_guru_aktif ON guru(aktif);
CREATE INDEX idx_users_username ON users(username);

-- ========================================
-- END OF DATABASE SETUP
-- ========================================

-- Notes:
-- 1. Default admin login: username = 'admin', password = 'admin123'
-- 2. Default guru login: username = 'guru', password = 'admin123'
-- 3. All images referenced in this SQL should be placed in the 'uploads/' directory
-- 4. Database uses utf8mb4 unicode collation for full UTF-8 support
-- 5. All tables use InnoDB engine for ACID compliance and foreign key support