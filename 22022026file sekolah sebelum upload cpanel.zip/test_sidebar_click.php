<?php
/**
 * Test script untuk mendiagnosa masalah klik sidebar
 */

require 'config/database.php';

// Cek apakah user sudah login
if (!isset($_SESSION['user_id'])) {
    echo "<h2>Login Diperlukan</h2>";
    echo "<p>Silakan login terlebih dahulu: <a href='admin/login.php'>Login</a></p>";
    echo "<p>Username: admin | Password: admin123 (setelah menjalankan fix_password.php)</p>";
    exit;
}

// Simulasi halaman admin
$_SESSION['user_id'] = $_SESSION['user_id'];
$_SESSION['username'] = $_SESSION['username'] ?? 'admin';
$_SESSION['nama'] = $_SESSION['nama'] ?? 'Administrator';
$_SESSION['role'] = $_SESSION['role'] ?? 'admin';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test Sidebar Click</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: #f5f7fa;
        }
        .main-content {
            margin-left: 280px;
            padding: 30px;
        }
        .test-card {
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 2px 15px rgba(0,0,0,0.08);
            margin-bottom: 20px;
        }
        .test-link {
            display: inline-block;
            padding: 10px 20px;
            margin: 10px;
            background: #4A90E2;
            color: white;
            text-decoration: none;
            border-radius: 10px;
            cursor: pointer;
        }
        .test-link:hover {
            background: #357ABD;
            transform: translateY(-2px);
        }
        .status-ok {
            color: #28a745;
            font-weight: bold;
        }
        .status-error {
            color: #dc3545;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <?php include 'admin/includes/sidebar.php'; ?>
    
    <div class="main-content">
        <h1><i class="fas fa-bug"></i> Diagnosa Masalah Sidebar</h1>
        
        <div class="test-card">
            <h3>1. Cek File user.php</h3>
            <?php
            $user_file = __DIR__ . '/admin/user.php';
            if (file_exists($user_file)) {
                echo "<p class='status-ok'>✅ File admin/user.php ada</p>";
                echo "<p>Path: " . htmlspecialchars($user_file) . "</p>";
                echo "<p>URL: <a href='admin/user.php' target='_blank'>admin/user.php</a></p>";
            } else {
                echo "<p class='status-error'>❌ File admin/user.php tidak ditemukan!</p>";
            }
            ?>
        </div>
        
        <div class="test-card">
            <h3>2. Cek Path Relatif</h3>
            <p>Link di sidebar menggunakan path relatif: <code>user.php</code></p>
            <p>Dari lokasi sidebar (admin/includes/), path seharusnya:</p>
            <ul>
                <li><code>../user.php</code> untuk file di admin/</li>
            </ul>
            <p><strong>Isu kemungkinan:</strong> Path di sidebar mungkin tidak benar untuk semua lokasi</p>
        </div>
        
        <div class="test-card">
            <h3>3. Test Link Langsung</h3>
            <p>Klik link di bawah ini untuk test apakah user.php bisa diakses:</p>
            <a href="admin/user.php" class="test-link">
                <i class="fas fa-users-cog me-2"></i>Buka Manajemen User
            </a>
            <p class="mt-3"><small>Jika link ini bekerja tapi tidak dari sidebar, berarti ada masalah dengan path di sidebar</small></p>
        </div>
        
        <div class="test-card">
            <h3>4. Test Klik Navigation</h3>
            <p>Coba klik menu "Manajemen User" di sidebar di kiri.</p>
            <p id="clickTest">Menunggu klik...</p>
        </div>
        
        <div class="test-card">
            <h3>5. Link Alternatif</h3>
            <p>Jika sidebar tidak berfungsi, gunakan link di bawah:</p>
            <div class="list-group">
                <a href="admin/index.php" class="list-group-item list-group-item-action">
                    <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                </a>
                <a href="admin/berita.php" class="list-group-item list-group-item-action">
                    <i class="fas fa-newspaper me-2"></i>Berita
                </a>
                <a href="admin/guru.php" class="list-group-item list-group-item-action">
                    <i class="fas fa-users me-2"></i>Guru & Staf
                </a>
                <a href="admin/user.php" class="list-group-item list-group-item-action" style="background: #e3f2fd; border-left: 4px solid #2196F3;">
                    <i class="fas fa-users-cog me-2"></i><strong>Manajemen User</strong>
                </a>
                <a href="admin/pengaturan.php" class="list-group-item list-group-item-action">
                    <i class="fas fa-cog me-2"></i>Pengaturan
                </a>
            </div>
        </div>
        
        <div class="alert alert-info">
            <strong>💡 Tips:</strong>
            <ul class="mb-0 mt-2">
                <li>Jika link langsung di atas bekerja, masalahnya adalah path di sidebar</li>
                <li>Jika semua link tidak bekerja, mungkin ada masalah dengan JavaScript atau CSS</li>
                <li>Cek browser console (F12) untuk error JavaScript</li>
            </ul>
        </div>
    </div>
    
    <script>
    // Test click detection
    document.addEventListener('DOMContentLoaded', function() {
        const userMenuLink = document.querySelector('.nav-item[href="user.php"]');
        const clickTest = document.getElementById('clickTest');
        
        if (userMenuLink) {
            console.log('User menu link found:', userMenuLink);
            
            userMenuLink.addEventListener('click', function(e) {
                console.log('User menu clicked!', e);
                clickTest.innerHTML = '<span class="status-ok">✅ Link diklik! Mengarah ke ' + this.href + '</span>';
            });
            
            clickTest.innerHTML = '<span class="status-ok">✅ Menu Manajemen User ditemukan di sidebar</span>';
        } else {
            console.log('User menu link NOT found!');
            clickTest.innerHTML = '<span class="status-error">❌ Menu Manajemen User TIDAK ditemukan di sidebar</span>';
        }
        
        // Cek semua nav items
        const allNavItems = document.querySelectorAll('.nav-item');
        console.log('Total nav items:', allNavItems.length);
        
        allNavItems.forEach((item, index) => {
            console.log(`Nav item ${index}:`, {
                text: item.textContent.trim(),
                href: item.getAttribute('href'),
                pointerEvents: window.getComputedStyle(item).pointerEvents
            });
        });
    });
    </script>
</body>
</html>