# Panduan Keamanan Sistem SLB Rumah Kita Batam

## 📋 Daftar Isi
1. [Fitur Keamanan yang Diimplementasikan](#fitur-keamanan)
2. [Instalasi Database](#instalasi-database)
3. [Konfigurasi](#konfigurasi)
4. [Penggunaan](#penggunaan)
5. [Testing Keamanan](#testing)
6. [Troubleshooting](#troubleshooting)
7. [Best Practices](#best-practices)

---

## 🔒 Fitur Keamanan yang Diimplementasikan

### Phase 1: Keamanan Dasar (Sudah Diimplementasikan)

#### 1. Rate Limiting (Batas Percobaan Login)
- **Maksimal percobaan:** 5 kali dalam 15 menit
- **Lockout time:** 15 menit jika melebihi batas
- **Mencegah:** Brute force attack, password guessing
- **Status:** ✅ Aktif

#### 2. Secure Session Management
- **Session timeout:** 30 menit tidak aktif
- **Secure cookies:** HttpOnly, Secure (jika HTTPS), SameSite=Strict
- **Session regeneration:** Setiap 10 menit
- **Mencegah:** Session fixation, session hijacking
- **Status:** ✅ Aktif

#### 3. Input Sanitization
- **Fungsi:** `sanitizeInput()`
- **Mencegah:** XSS (Cross-Site Scripting)
- **Status:** ✅ Aktif di login

#### 4. Security Logging
- **Login attempts:** Dicatat lengkap dengan timestamp
- **Failed logins:** Termonitor
- **Successful logins:** Tercatat untuk audit
- **Status:** ✅ Aktif

#### 5. Password Strength Validation
- **Minimal:** 8 karakter
- **Wajib:** 1 huruf kapital, 1 huruf kecil, 1 angka, 1 karakter spesial
- **Status:** ✅ Fungsi tersedia (opsional digunakan)

---

## 🗄 Instalasi Database

### Langkah 1: Import SQL Security Tables

Jalankan perintah berikut di phpMyAdmin atau terminal MySQL:

```bash
mysql -u root -p rumahkitabtmweb_ftth < database_security.sql
```

Atau:
1. Buka phpMyAdmin
2. Pilih database `rumahkitabtmweb_ftth`
3. Klik tab "SQL"
4. Copy-paste isi `database_security.sql`
5. Klik "Go"

### Langkah 2: Verifikasi Tabel Terbuat

Pastikan tabel-tabel berikut ada:
- `login_attempts` - Untuk rate limiting
- `security_logs` - Untuk audit trail
- `csrf_tokens` - Untuk CSRF protection (opsional)

```sql
SHOW TABLES LIKE '%login_attempts%';
SHOW TABLES LIKE '%security_logs%';
```

---

## ⚙️ Konfigurasi

### File yang Ditambahkan:
```
config/security.php         - Fungsi-fungsi keamanan
database_security.sql      - SQL untuk tabel keamanan
SECURITY_GUIDE.md          - Dokumentasi ini
```

### File yang Dimodifikasi:
```
admin/login.php           - Ditambahkan rate limiting & security logging
admin/auth.php            - Ditambahkan session timeout check
```

### Pengaturan yang Bisa Diubah (di config/security.php):

```php
// Rate Limiting
define('MAX_LOGIN_ATTEMPTS', 5);      // Ubah sesuai kebutuhan
define('LOGIN_LOCKOUT_TIME', 900);     // 15 menit (detik)
define('RATE_LIMIT_WINDOW', 900);       // 15 menit (detik)

// Session Timeout
define('SESSION_TIMEOUT', 1800);       // 30 menit (detik)
```

---

## 📖 Penggunaan

### Menggunakan Security Functions di File Baru

```php
<?php
// Include security configuration di awal file
require_once '../config/security.php';

// Initialize secure session
initSecureSession();

// Sanitize input
$username = sanitizeInput($_POST['username']);

// Check rate limiting untuk custom login
$rateLimit = checkRateLimit();
if (!$rateLimit['allowed']) {
    echo $rateLimit['message'];
    exit;
}

// Log security event
logSecurityEvent('CUSTOM_EVENT', 'Description here', $username);
?>
```

### Menggunakan Password Validation

```php
$password = $_POST['password'];
$validation = validatePasswordStrength($password);

if ($validation !== true) {
    echo "Password tidak valid:<br>";
    echo implode("<br>", $validation);
} else {
    // Password valid, lanjutkan
}
```

### Menggunakan CSRF Protection (Opsional)

```php
// Di form HTML:
<input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">

// Di proses form:
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCSRFToken($_POST['csrf_token'])) {
        die("CSRF token invalid!");
    }
    // Lanjutkan proses
}
```

---

## 🧪 Testing Keamanan

### Test 1: Rate Limiting
1. Buka halaman login
2. Coba login dengan password salah 6 kali
3. **Hasil yang diharapkan:** Pesan "Terlalu banyak percobaan login"
4. Cek tabel `login_attempts` di database

### Test 2: Session Timeout
1. Login dengan benar
2. Tunggu 31 menit (lebih dari SESSION_TIMEOUT)
3. Refresh halaman
4. **Hasil yang diharapkan:** Redirect ke halaman login

### Test 3: Secure Session
1. Login
2. Buka Developer Tools > Application > Cookies
3. **Cek:**
   - Cookie name: `SLB_SESSION_ID`
   - HttpOnly: `✓`
   - Secure: `✓` (jika HTTPS)
   - SameSite: `Strict`

### Test 4: Input Sanitization
1. Coba login dengan: `<script>alert('XSS')</script>`
2. **Hasil yang diharapkan:** Input disanitasi menjadi `<script>alert(&#39;XSS&#39;)</script>`

### Test 5: Security Logs
1. Login gagal beberapa kali
2. Login berhasil
3. Cek tabel `security_logs`
4. **Hasil yang diharapkan:** Semua event tercatat

---

## 🔧 Troubleshooting

### Masalah: "Call to undefined function initSecureSession()"

**Solusi:**
Pastikan `require_once '../config/security.php';` ada di awal file sebelum menggunakan fungsi keamanan.

### Masalah: Rate Limiting Tidak Bekerja

**Solusi:**
1. Pastikan tabel `login_attempts` sudah dibuat
2. Cek koneksi database di `config/security.php`
3. Pastikan fungsi `checkRateLimit()` dipanggil sebelum login

### Masalah: Session Timeout Terlalu Cepat

**Solusi:**
Ubah `SESSION_TIMEOUT` di `config/security.php`:
```php
define('SESSION_TIMEOUT', 3600); // 1 jam
```

### Masalah: User Tidak Bisa Login Setelah Lockout

**Solusi:**
1. Tunggu sampai lockout time habis (cek di database)
2. Atau jalankan SQL ini untuk menghapus lockout:
```sql
DELETE FROM login_attempts WHERE ip_address = 'IP_ADDRESS_HERE';
```

### Masalah: Database Error pada Fungsi Keamanan

**Solusi:**
Pastikan variabel `$pdo` sudah didefinisikan sebagai global di fungsi:
```php
function checkRateLimit() {
    global $pdo; // Tambahkan ini
    // ...
}
```

---

## 🛡️ Best Practices

### Untuk Developer:
1. ✅ Selalu include `config/security.php` di awal file admin
2. ✅ Gunakan `initSecureSession()` untuk semua halaman yang butuh session
3. ✅ Sanitize semua input user dengan `sanitizeInput()`
4. ✅ Log aktivitas penting dengan `logSecurityEvent()`
5. ✅ Validasi password sebelum menyimpan
6. ✅ Gunakan prepared statements untuk semua query (sudah ada di helper.php)
7. ✅ Cek role user dengan `require_admin()` untuk halaman admin-only

### Untuk Administrator:
1. ✅ Cek `security_logs` secara berkala untuk aktivitas mencurigakan
2. ✅ Pantau IP yang sering gagal login
3. ✅ Reset password user jika terdeteksi kompromi
4. ✅ Backup database security logs secara berkala
5. ✅ Update konfigurasi sesuai kebutuhan

### Untuk Deployment:
1. ✅ Gunakan HTTPS (SSL certificate)
2. ✅ Set `session.cookie_secure` ke 1 (otomatis jika HTTPS)
3. ✅ Disable error display di production
4. ✅ Aktifkan event scheduler untuk auto-cleanup (opsional)
5. ✅ Regular security audit

---

## 📊 Monitoring & Maintenance

### Auto-Cleanup

Sistem otomatis membersihkan:
- **Login attempts:** Lebih dari 24 jam
- **Security logs:** Lebih dari 90 hari
- **CSRF tokens:** Sudah expired atau digunakan

### Manual Cleanup

Jalankan prosedur ini secara berkala:
```sql
CALL clean_security_tables();
```

### Aktifkan Auto-Cleanup (Opsional)

Di MySQL server:
```sql
SET GLOBAL event_scheduler = ON;
CREATE EVENT IF NOT EXISTS clean_security_event
ON SCHEDULE EVERY 1 DAY
DO CALL clean_security_tables();
```

---

## 🔄 Roadmap Pengembangan

### Phase 2: Keamanan Lanjutan (Rencana)
- [ ] Two-Factor Authentication (2FA)
- [ ] Email verification
- [ ] Password reset dengan token
- [ ] Account lockout policy
- [ ] IP whitelisting untuk admin
- [ ] CSRF protection untuk semua form POST

### Phase 3: Monitoring (Rencana)
- [ ] Dashboard security monitoring
- [ ] Alert email untuk aktivitas mencurigakan
- [ ] Real-time login attempt monitoring
- [ ] Integration dengan security tools

---

## 📞 Support

Jika mengalami masalah:
1. Cek dokumentasi ini terlebih dahulu
2. Lihat bagian Troubleshooting
3. Cek logs error PHP
4. Hubungi developer jika masalah berlanjut

---

## 📝 Changelog

### Version 1.0.0 (2026-02-21)
- Initial implementation
- Rate limiting untuk login
- Secure session management
- Input sanitization
- Security logging
- Password strength validation
- Documentation

---

**Terakhir diupdate:** 21 Februari 2026  
**Versi:** 1.0.0  
**Status:** Production Ready ✅