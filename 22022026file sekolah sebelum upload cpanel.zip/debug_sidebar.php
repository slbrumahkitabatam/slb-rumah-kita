<?php
// Debug script to see actual HTML output of sidebar
session_start();
$_SESSION['user_id'] = 1;
$_SESSION['username'] = 'admin';
$_SESSION['nama'] = 'Administrator';
$_SESSION['role'] = 'admin';

$active_menu = 'user';

// Start output buffering
ob_start();
include 'admin/includes/sidebar.php';
$sidebar_html = ob_get_clean();

echo "<h1>Debug Sidebar HTML</h1>";
echo "<h2>Cek apakah 'Manajemen User' ada di HTML:</h2>";

// Search for User Management section
if (strpos($sidebar_html, 'Manajemen User') !== false) {
    echo "<div class='alert alert-success'>✅ TEKS 'Manajemen User' DITEMUKAN di HTML</div>";
    
    // Count occurrences
    $count = substr_count($sidebar_html, 'Manajemen User');
    echo "<p>Jumlah kemunculan: $count</p>";
    
    // Extract the section around Manajemen User
    $pos = strpos($sidebar_html, 'Manajemen User');
    $start = max(0, $pos - 500);
    $end = min(strlen($sidebar_html), $pos + 500);
    $section = substr($sidebar_html, $start, $end - $start);
    
    echo "<h3>Section di sekitar 'Manajemen User':</h3>";
    echo "<pre style='background: #f5f5f5; padding: 20px; border-radius: 5px; overflow: auto;'>";
    echo htmlspecialchars($section);
    echo "</pre>";
} else {
    echo "<div class='alert alert-danger'>❌ TEKS 'Manajemen User' TIDAK DITEMUKAN di HTML</div>";
}

// Check for user.php link
if (strpos($sidebar_html, 'href="user.php"') !== false) {
    echo "<div class='alert alert-success'>✅ LINK 'user.php' DITEMUKAN di HTML</div>";
} else {
    echo "<div class='alert alert-danger'>❌ LINK 'user.php' TIDAK DITEMUKAN di HTML</div>";
}

// Check for nav-label Manajemen User
if (strpos($sidebar_html, '<span class="nav-label">Manajemen User</span>') !== false) {
    echo "<div class='alert alert-success'>✅ NAV-LABEL 'Manajemen User' DITEMUKAN</div>";
} else {
    echo "<div class='alert alert-danger'>❌ NAV-LABEL 'Manajemen User' TIDAK DITEMUKAN</div>";
}

echo "<hr>";
echo "<h2>FULL SIDEBAR HTML:</h2>";
echo "<pre style='background: #f5f5f5; padding: 20px; border-radius: 5px; overflow: auto; max-height: 800px;'>";
echo htmlspecialchars($sidebar_html);
echo "</pre>";
?>