<?php
require_once 'config/database.php';

echo "<h2>Checking 'Tentang Sekolah' Data in Database</h2>";
echo "<hr>";

// Check if halaman table exists
try {
    $check_table = fetchOne("SHOW TABLES LIKE 'halaman'");
    if (!$check_table) {
        echo "<p style='color: red;'><strong>ERROR:</strong> Tabel 'halaman' tidak ditemukan!</p>";
        echo "<p>Silakan jalankan database_complete.sql untuk membuat tabel.</p>";
        exit;
    }
    echo "<p style='color: green;'>✓ Tabel 'halaman' ditemukan.</p>";
} catch (Exception $e) {
    echo "<p style='color: red;'><strong>ERROR:</strong> " . $e->getMessage() . "</p>";
    exit;
}

// Check for data with slug 'tentang' or 'tentang-sekolah'
$profil_tentang = fetchOne("SELECT * FROM halaman WHERE slug = 'tentang'");
$profil_tentang_sekolah = fetchOne("SELECT * FROM halaman WHERE slug = 'tentang-sekolah'");

echo "<hr>";
echo "<h3>Pengecekan Data:</h3>";

// Check for duplicate slugs
$duplicates = fetchAll("SELECT slug, COUNT(*) as count FROM halaman GROUP BY slug HAVING COUNT(*) > 1");
if ($duplicates) {
    echo "<div style='background: #fff3cd; color: #856404; padding: 15px; border-radius: 5px; margin-bottom: 15px;'>";
    echo "<strong>⚠️ WARNING: Slug Duplikat Ditemukan!</strong><br><br>";
    foreach ($duplicates as $dup) {
        echo "- Slug '<code>" . htmlspecialchars($dup['slug']) . "</code>' muncul " . $dup['count'] . " kali<br>";
    }
    echo "<br>Ini menyebabkan error saat mencoba menyimpan data.";
    echo "</div>";
}

echo "<h3>Data dengan slug 'tentang':</h3>";
if ($profil_tentang) {
    echo "<p style='color: green;'>✓ Data 'tentang' ditemukan!</p>";
    echo "<table border='1' cellpadding='10' style='border-collapse: collapse;'>";
    echo "<tr><th>Kolom</th><th>Nilai</th></tr>";
    echo "<tr><td><strong>ID</strong></td><td>" . htmlspecialchars($profil_tentang['id']) . "</td></tr>";
    echo "<tr><td><strong>Judul</strong></td><td>" . htmlspecialchars($profil_tentang['judul']) . "</td></tr>";
    echo "<tr><td><strong>Slug</strong></td><td><code>" . htmlspecialchars($profil_tentang['slug']) . "</code></td></tr>";
    echo "<tr><td><strong>Aktif</strong></td><td>" . ($profil_tentang['aktif'] ? 'Ya' : 'Tidak') . "</td></tr>";
    echo "<tr><td><strong>Urutan</strong></td><td>" . htmlspecialchars($profil_tentang['urutan']) . "</td></tr>";
    echo "</table>";
} else {
    echo "<p style='color: orange;'>⚠️ Data dengan slug 'tentang' tidak ditemukan.</p>";
}

echo "<hr>";
echo "<h3>Data dengan slug 'tentang-sekolah':</h3>";
if ($profil_tentang_sekolah) {
    echo "<p style='color: green;'>✓ Data 'tentang-sekolah' ditemukan!</p>";
    echo "<table border='1' cellpadding='10' style='border-collapse: collapse;'>";
    echo "<tr><th>Kolom</th><th>Nilai</th></tr>";
    echo "<tr><td><strong>ID</strong></td><td>" . htmlspecialchars($profil_tentang_sekolah['id']) . "</td></tr>";
    echo "<tr><td><strong>Judul</strong></td><td>" . htmlspecialchars($profil_tentang_sekolah['judul']) . "</td></tr>";
    echo "<tr><td><strong>Slug</strong></td><td><code>" . htmlspecialchars($profil_tentang_sekolah['slug']) . "</code></td></tr>";
    echo "<tr><td><strong>Aktif</strong></td><td>" . ($profil_tentang_sekolah['aktif'] ? 'Ya' : 'Tidak') . "</td></tr>";
    echo "<tr><td><strong>Urutan</strong></td><td>" . htmlspecialchars($profil_tentang_sekolah['urutan']) . "</td></tr>";
    echo "</table>";
    
    echo "<hr>";
    echo "<h3>Full HTML Content:</h3>";
    echo "<div style='background: #f5f5f5; padding: 15px; border-radius: 5px;'>";
    echo htmlspecialchars($profil_tentang_sekolah['isi']);
    echo "</div>";
} else {
    echo "<p style='color: orange;'>⚠️ Data dengan slug 'tentang-sekolah' tidak ditemukan.</p>";
}

// Determine which data to use
$profil = $profil_tentang ? $profil_tentang : $profil_tentang_sekolah;

if (!$profil) {
    echo "<p style='color: red;'><strong>WARNING:</strong> Tidak ada data 'Tentang Sekolah' yang ditemukan!</p>";
    echo "<p>Ini sebabnya muncul pesan 'Memuat informasi...' di halaman utama.</p>";
} else {
    echo "<hr>";
    echo "<div style='background: #d4edda; color: #155724; padding: 15px; border-radius: 5px;'>";
    echo "<strong>ℹ️ INFO:</strong> index.php mencari data dengan slug '<code>tentang</code>'.<br>";
    if ($profil_tentang) {
        echo "Data ditemukan dengan slug yang benar. Halaman seharusnya sudah tampil dengan benar.";
    } else {
        echo "Data ditemukan dengan slug '<code>tentang-sekolah</code>' yang tidak cocok dengan query di index.php.";
    }
    echo "</div>";
}

// Show all records in halaman table
echo "<hr>";
echo "<h3>Semua data di tabel halaman:</h3>";

$all_halaman = fetchAll("SELECT * FROM halaman ORDER BY urutan");
if ($all_halaman) {
    echo "<table border='1' cellpadding='10' style='border-collapse: collapse;'>";
    echo "<tr><th>ID</th><th>Judul</th><th>Slug</th><th>Aktif</th><th>Urutan</th></tr>";
    foreach ($all_halaman as $row) {
        $active_style = $row['aktif'] ? 'color: green;' : 'color: red;';
        echo "<tr>";
        echo "<td>" . htmlspecialchars($row['id']) . "</td>";
        echo "<td>" . htmlspecialchars($row['judul']) . "</td>";
        echo "<td><code>" . htmlspecialchars($row['slug']) . "</code></td>";
        echo "<td style='{$active_style}'>" . ($row['aktif'] ? 'Ya' : 'Tidak') . "</td>";
        echo "<td>" . htmlspecialchars($row['urutan']) . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p style='color: red;'>Tabel halaman kosong!</p>";
}

echo "<hr>";
echo "<h3>Solusi:</h3>";
echo "<ol>";
echo "<li>Jika data 'tentang' tidak ada: Jalankan script insert data di bawah ini</li>";
echo "<li>Jika data ada tapi aktif=0: Update kolom aktif menjadi 1</li>";
echo "<li>Jika data sudah benar tapi tetap tidak tampil: Refresh halaman index.php</li>";
echo "</ol>";

// Button to fix data
echo "<hr>";
echo "<h3>Perbaiki Otomatis:</h3>";
echo "<form method='post'>";
echo "<button type='submit' name='fix_tentang' style='padding: 10px 20px; background: #4A90E2; color: white; border: none; border-radius: 5px; cursor: pointer; font-size: 16px;'>";
echo "🔧 Insert/Ulang Data 'Tentang Sekolah'";
echo "</button>";
echo "</form>";

if (isset($_POST['fix_tentang'])) {
    echo "<hr>";
    echo "<h3>Menghapus data lama (jika ada)...</h3>";
    execute("DELETE FROM halaman WHERE slug = 'tentang'");
    echo "<p style='color: green;'>✓ Data lama dihapus</p>";
    
    echo "<h3>Insert data baru...</h3>";
    $isi = '<h2>Tentang SLB Rumah Kita Batam</h2>
<p>SLB Rumah Kita Batam adalah sekolah luar biasa yang berdedikasi untuk memberikan pendidikan berkualitas bagi anak-anak berkebutuhan khusus. Berdiri sejak tahun 2015, sekolah kami telah melayani ratusan siswa dengan berbagai kebutuhan pendidikan khusus.</p>

<h3>Visi</h3>
<p>Menjadi sekolah luar biasa terdepan yang inklusif dan berdaya saing di tingkat nasional.</p>

<h3>Misi</h3>
<ol>
    <li>Menyelenggarakan pendidikan berkualitas bagi anak berkebutuhan khusus</li>
    <li>Mengembangkan potensi siswa secara optimal</li>
    <li>Membangun kerjasama dengan berbagai pihak</li>
    <li>Menciptakan lingkungan belajar yang inklusif</li>
</ol>

<p>Kami berkomitmen untuk memberikan pelayanan terbaik dengan pendekatan individual bagi setiap siswa, mengembangkan potensi mereka secara optimal, dan mempersiapkan mereka untuk menjadi mandiri dan produktif.</p>';
    
    execute("INSERT INTO halaman (judul, slug, isi, urutan, aktif, icon) VALUES ('Tentang Sekolah', 'tentang', ?, 1, 1, 'fa-school')", [$isi]);
    echo "<p style='color: green;'>✓ Data baru berhasil diinsert!</p>";
    echo "<p><a href='index.php'>Kembali ke Beranda</a></p>";
    echo "<p><a href='check_tentang_data.php'>Refresh halaman ini</a></p>";
}

echo "<hr>";
echo "<p><a href='index.php'>← Kembali ke Beranda</a></p>";
?>