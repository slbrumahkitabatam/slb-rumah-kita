<?php
/**
 * Script untuk memperbaiki password admin
 * 
 * Password yang akan di-set:
 * - Username: admin
 * - Password: admin123
 */

require 'config/database.php';

echo "<h1>Fix Password Admin</h1>";

// Hash password baru "admin123"
$new_password = 'admin123';
$hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

echo "<p>New password hash for 'admin123':</p>";
echo "<code>" . htmlspecialchars($hashed_password) . "</code><br><br>";

// Update password admin
try {
    $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE username = 'admin'");
    $stmt->execute([$hashed_password]);
    
    if ($stmt->rowCount() > 0) {
        echo "<p style='color: green; font-size: 18px;'>✅ Password admin berhasil diperbarui!</p>";
        echo "<p>Username: <strong>admin</strong></p>";
        echo "<p>Password: <strong>admin123</strong></p>";
        
        // Verify password
        $user = fetchOne("SELECT * FROM users WHERE username = 'admin'");
        if ($user && password_verify('admin123', $user['password'])) {
            echo "<p style='color: green; font-size: 18px;'>✅ Password verification successful!</p>";
        } else {
            echo "<p style='color: red;'>❌ Password verification failed!</p>";
        }
    } else {
        echo "<p style='color: red;'>❌ User 'admin' tidak ditemukan!</p>";
        
        // Cek semua user yang ada
        echo "<h2>User yang ada di database:</h2>";
        $users = $pdo->query("SELECT id, username, nama FROM users")->fetchAll();
        foreach ($users as $u) {
            echo "<p>ID: {$u['id']}, Username: {$u['username']}, Nama: {$u['nama']}</p>";
        }
    }
} catch (PDOException $e) {
    echo "<p style='color: red;'>❌ Error: " . htmlspecialchars($e->getMessage()) . "</p>";
}

echo "<br><hr>";
echo "<p><strong>PENTING:</strong> Hapus file ini setelah digunakan untuk alasan keamanan!</p>";
echo "<p><a href='admin/login.php'>Klik di sini untuk login</a></p>";
?>